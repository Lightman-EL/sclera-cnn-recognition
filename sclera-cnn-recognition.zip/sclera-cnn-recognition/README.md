# Sclera recognition with convolutional neural networks (UBIRIS.v2)

Code and results for the article **“Application of a Convolutional Neural Network for Biometric Human Recognition from Sclera Images”** by Elnur Khamidov (“TIIAME” National Research University, Tashkent). The citation of the article will be added after publication.

[Русская версия](README_ru.md)

The code implements a fully automatic sclera recognition pipeline and all experiments of the article:

1. **Sclera segmentation:** U-Net with an ImageNet-pretrained ResNet-18 encoder, trained on manually annotated UBIRIS.v2 images.
2. **Region extraction:** the sclera bounding box is cropped and resized to 384 × 768 pixels with the aspect ratio preserved.
3. **Vascular enhancement (optional):** CLAHE on the green channel and multiscale Frangi vesselness computed on the GPU; the network input is either RGB or the three channels *E* (enhanced green), *V* (vesselness) and *M* (mask).
4. **Feature learning and matching:** SV-CNN, a compact VGG-style network with global average pooling (1.37 M parameters), compared with a shallow sclera CNN, a fine-tuned ResNet-18 and an LBP–SVM baseline. Identification uses the softmax classifier; verification uses the cosine similarity of the embeddings.

![Pipeline](docs/pipeline.png)

## Main results

UBIRIS.v2, 10,919 usable images. P1: within-session protocol, 516 eyes. P2: cross-session protocol, 222 eyes, mean of both directions. Accuracy is the rank-1 identification rate; values are mean ± SD over three runs unless marked otherwise.

| Method | Input | Params, M | P1 accuracy, % | P1 EER, % | P2 accuracy, % | P2 EER, % |
|---|---|---|---|---|---|---|
| LBP–SVM (1 run) | *E* | – | 8.40 | 45.57 | – | – |
| Shallow CNN | RGB | 47.56 | 40.69 ± 4.55 | 38.46 ± 1.47 | – | – |
| ResNet-18 (ImageNet) | RGB | 11.44 | **95.10 ± 0.36** | **2.63 ± 0.08** | **66.28** | **8.44** |
| ResNet-18 (ImageNet) | *E*, *V*, *M* | 11.44 | 87.62 ± 0.71 | 6.30 ± 0.47 | – | – |
| SV-CNN, 60 epochs | RGB | 1.37 | 59.85 ± 5.74 | 20.45 ± 0.78 | 20.23 | 20.95 |
| SV-CNN, 60 epochs | *E*, *V*, *M* | 1.37 | 52.36 ± 0.42 | 24.14 ± 0.85 | 17.58 | 25.78 |
| SV-CNN, no dropout, 150 epochs (1 run) | RGB | 1.37 | 86.97 | 17.33 | – | – |
| SV-CNN, no dropout, 150 epochs (1 run) | *E*, *V*, *M* | 1.37 | 81.74 | 19.95 | – | – |

Sclera segmentation on 129 held-out images of unseen eyes: precision 0.919, recall 0.942, F1-score 0.928, IoU 0.868.

Main findings:

- **Vessel enhancement did not help.** At the resolution of UBIRIS.v2, the vessel-enhanced input lowered the accuracy in every comparison, by 2.7–7.5 percentage points, for both SV-CNN and ResNet-18.
- **Transfer learning was decisive.** The ImageNet-pretrained ResNet-18 clearly outperformed the networks trained from scratch and converged much faster.
- **Session changes are the main source of errors.** Accuracy dropped substantially between acquisition sessions, even for ResNet-18.

All tables of the article, the numbers used in the text and the figures are in [`results/`](results).

## Repository structure

| File | Purpose | Section of the article |
|---|---|---|
| `config.py` | Paths and all hyper-parameters | 2 |
| `check_dataset.py` | Checks the dataset, the annotations and the protocol sizes | 2.8 |
| `seg.py` | Sclera segmentation: training, evaluation (Table 4), masks for all images | 2.2, 3.1 |
| `data.py` | Image index, region extraction, CLAHE, augmentation, protocols P1 and P2 | 2.3, 2.6, 2.8 |
| `enhance.py` | GPU Frangi vesselness, input tensor *E*, *V*, *M*, standardization | 2.4 |
| `models.py` | SV-CNN, shallow CNN, ResNet-18 | 2.5, 2.9 |
| `train.py` | Training and evaluation of one configuration | 2.6, 2.7 |
| `lbp_svm.py` | LBP–SVM baseline | 2.9 |
| `metrics.py` | Accuracy, macro-F1, EER, GAR at fixed FAR | 2.10 |
| `run_all.py` | Main experiments (Tables 5, 6, 8) | 3.2, 3.3, 3.5 |
| `run_extra.py` | Additional experiments (ResNet-18 on P2 and on *E*, *V*, *M*; 150-epoch training) | 3.2, 3.4, 3.5 |
| `make_tables.py`, `make_extra.py` | Tables and figures from the run files | 3 |
| `timing.py` | Processing time per image | 3.6 |
| `sclera_experiments.ipynb`, `sclera_extra_experiments.ipynb` | The same steps as notebooks | – |
| `results/` | One JSON file per run (metrics, training history, split sizes), tables and figures | 3 |

## Installation

Tested with Python 3.11 on Windows with an NVIDIA GeForce RTX 4060 Laptop GPU (8 GB).

```
conda create -n sclera python=3.11 -y
conda activate sclera
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
pip install -r requirements.txt
python -c "import torch; print(torch.cuda.is_available())"
```

The ImageNet weights of ResNet-18 are downloaded by torchvision on first use.

## Data

The images and the annotations are **not** included in this repository.

- **UBIRIS.v2**: available on request from the SOCIA Lab, University of Beira Interior (http://iris.di.ubi.pt/ubiris2.html). File names follow the pattern `C<eye>_S<session>_I<image>`, for example `C12_S2_I7.tiff`. The folder is searched recursively.
- **Sclera annotations**: manually annotated binary sclera masks of UBIRIS.v2 images (683 masks were used in the article). Each mask is named with the UBIRIS.v2 key, e.g. `C100_S1_I14.png`, and is either a 0/255 PNG or an RGBA PNG with the mask in the alpha channel.

Set the paths in `config.py` or with environment variables. The defaults are `data/UBIRIS.v2` and `data/sclera_annotations` inside the repository.

```
# Windows
set SCLERA_DATA_ROOT=D:\datasets\UBIRIS.v2
set SCLERA_ANNOT_ROOT=D:\datasets\sclera_annotations
# Linux / macOS
export SCLERA_DATA_ROOT=/data/UBIRIS.v2
export SCLERA_ANNOT_ROOT=/data/sclera_annotations
```

## Reproducing the experiments

```
python check_dataset.py      # dataset and annotations
python seg.py                # segmentation network, Table 4, masks for all images
python check_dataset.py      # protocol sizes and numbers of comparisons
python run_all.py --smoke    # optional: every configuration for 2 epochs
python run_all.py            # main experiments: 29 trainings + LBP-SVM
python make_tables.py        # Tables 4, 5, 6, 8 and Fig. 3
python run_extra.py          # additional experiments (blocks A, B, C)
python make_extra.py         # Tables 5 and 8 with ResNet-18, Table 7, Figs. 3 and 4
python timing.py             # processing time per image
```

All runs are restartable: finished runs, identified by their JSON file in `results/`, are skipped. A single configuration can be trained directly, for example:

```
python train.py --model svcnn --input evm --protocol P1 --seed 0
python train.py --model resnet18 --input rgb --protocol P2 --fold 12 --seed 0
python train.py --model svcnn --input rgb --protocol P1 --no-dropout --epochs 150 --seed 0
```

On the laptop described above, with `NUM_WORKERS = 2`, one 60-epoch training under P1 takes about 2–3.5 hours; in total, the main experiments took about 66 hours of training and the additional experiments about 33 hours. The data split is fixed (`SPLIT_SEED = 0`); the seeds 0, 1 and 2 change only the initialization and the augmentation.

## What is not included

- UBIRIS.v2 images, sclera annotations and predicted masks: subject to the terms of their providers.
- Trained weights (`*.pt`) and score files (`*_scores.npz`): too large for the repository and derived from UBIRIS.v2.
- `results/index.json`: the image index contains local paths and is rebuilt automatically.

## License

The code is released under the [MIT License](LICENSE). The UBIRIS.v2 dataset and the sclera annotations are subject to their own terms of use.
