"""Checks the UBIRIS.v2 copy, the sclera annotations and (after seg.py) the protocols.

  python check_dataset.py
"""
import collections
import json

import numpy as np

import config as C
import data


def params_for(k):
    sv = 1_267_790 - (256 * 110 + 110) + (256 * k + k)
    sh = 5_730 + 92_160 * k + k
    rn = 11_176_512 + 512 * k + k
    return sv, sh, rn


def main():
    imgs, files = data.scan_images()
    print(f"DATA_ROOT: {C.DATA_ROOT}")
    print(f"image files: {len(files)};  with a C<eye>_S<session>_I<image> name: {len(imgs)}")
    if not imgs:
        print("\nNo file names matched NAME_REGEX. Examples from your folder:")
        for p in files[:25]:
            print("   ", p.relative_to(C.DATA_ROOT))
        print("Adjust NAME_REGEX in config.py.")
        return
    eyes = {r["cid"] for r in imgs}
    ses = collections.Counter(r["session"] for r in imgs)
    both = {c for c in eyes if {1, 2} <= {r["session"] for r in imgs if r["cid"] == c}}
    print(f"eyes (classes): {len(eyes)};  images per session: {dict(sorted(ses.items()))};  "
          f"eyes with both sessions: {len(both)}")

    ann = data.scan_annotations()
    keys = {r["key"] for r in imgs}
    print(f"\nSEG_ANNOT_ROOT: {C.SEG_ANNOT_ROOT}")
    print(f"annotation masks found: {len(ann)};  matched to UBIRIS.v2 images: {len(set(ann) & keys)}")
    if ann and not set(ann) & keys:
        print("  WARNING: mask names do not match image names, e.g.", list(ann.values())[:3])

    if not C.PRED_MASK_DIR.exists() or not any(C.PRED_MASK_DIR.iterdir()):
        print("\nPredicted masks not found yet. Next step: python seg.py")
        return
    recs = data.load_index(rebuild=True)
    summ = json.loads((C.RESULTS_DIR / "index_summary.json").read_text())
    print(f"\nPredicted masks: usable images {summ['usable']} of {summ['images']} "
          f"(excluded: {summ['too_small']} with sclera < {C.MIN_SCLERA_PIXELS} px, {summ['no_mask']} without mask)")
    areas = np.array([r["area"] for r in recs])
    print(f"sclera area of usable images, px: median {np.median(areas):.0f}, 5th pct {np.percentile(areas, 5):.0f}")

    def pairs(ids):
        cnt = collections.Counter(recs[i]["cid"] for i in ids)
        n = len(ids); g = sum(v * (v - 1) // 2 for v in cnt.values())
        return g, n * (n - 1) // 2 - g

    tr, va, te = data.split_p1(recs)
    k1 = len(data.label_map(recs, tr))
    g, i = pairs(te)
    print(f"\nP1: classes {k1}; train {len(tr)}, val {len(va)}, test {len(te)}; pairs genuine {g}, impostor {i}")
    sv, sh, rn = params_for(k1)
    print(f"    parameters for K={k1}: SV-CNN {sv:,}  shallow CNN {sh:,}  ResNet-18 {rn:,}")
    for f in ("12", "21"):
        tr, va, te = data.split_p2(recs, f)
        g, i = pairs(te)
        print(f"P2 fold S{f[0]}->S{f[1]}: classes {len(data.label_map(recs, tr))}; train {len(tr)}, val {len(va)}, "
              f"test {len(te)}; pairs genuine {g}, impostor {i}")
    print(f"\nIndex saved to {C.RESULTS_DIR / 'index.json'}. Next: python run_all.py --smoke")


if __name__ == "__main__":
    main()
