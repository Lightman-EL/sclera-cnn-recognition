"""Collects the results into Tables 4, 5, 6 and 8 of the manuscript and draws Fig. 3 (ROC curves).

  python make_tables.py          -> results/tables.md, results/tables.csv, results/fig3_roc.png
"""
import argparse
import json

import numpy as np
import pandas as pd

import config as C

T5 = [("LBP–SVM", "lbp_svm", "e", ""), ("Shallow CNN", "shallow", "rgb", ""), ("ResNet-18", "resnet18", "rgb", ""),
      ("SV-CNN (RGB)", "svcnn", "rgb", ""), ("SV-CNN (E, V, M)", "svcnn", "evm", "")]
T6 = [("Input: RGB", "svcnn", "rgb", ""), ("Input: E (one channel)", "svcnn", "e", ""),
      ("Input: E, V", "svcnn", "ev", ""), ("Input: E, V, M (full model)", "svcnn", "evm", ""),
      ("Full model without batch normalization", "svcnn", "evm", "_nobn"),
      ("Full model without dropout", "svcnn", "evm", "_nodrop"),
      ("Full model without data augmentation", "svcnn", "evm", "_noaug")]
FOLDS = [("S1 → S2", "12"), ("S2 → S1", "21")]


def load(rd, ignore_budget=False):
    rows = []
    for p in sorted(rd.glob("P*.json")):
        r = json.loads(p.read_text())
        r.pop("history", None)
        tag = ("_nobn" if r.get("no_bn") else "") + ("_nodrop" if r.get("no_dropout") else "") + \
              ("_noaug" if r.get("no_aug") else "") + \
              (f"_ep{r['max_epochs']}" if not ignore_budget and r.get("max_epochs", C.MAX_EPOCHS) != C.MAX_EPOCHS else "")
        r["variant"] = f"{r['model']}_{r['input']}{tag}"
        rows.append(r)
    return pd.DataFrame(rows)


def ms(x, d=2):
    x = np.asarray(x, float)
    if len(x) == 0:
        return "n/a"
    return f"{x.mean():.{d}f} ± {x.std(ddof=1) if len(x) > 1 else 0.0:.{d}f}"


def sel(df, proto, model, inp, tag, fold=None):
    q = df[(df.protocol == proto) & (df.variant == f"{model}_{inp}{tag}")]
    return q if fold is None else q[q.fold == fold]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    a = ap.parse_args(argv)
    rd = C.HERE / "results_smoke" if a.smoke else C.RESULTS_DIR
    lines, csv = [], []

    sp = rd / "seg_results.json"
    if sp.exists():
        s = json.loads(sp.read_text())
        lines.append("## Table 4. Sclera segmentation on held-out annotated images (mean ± SD over images)\n")
        lines.append("| Images (train / val / test) | Precision | Recall | F1-score | IoU |")
        lines.append("|---|---|---|---|---|")
        lines.append(f"| {s['n_train']} / {s['n_val']} / {s['n_test']} | {s['precision']:.3f} ± {s['precision_sd']:.3f} | "
                     f"{s['recall']:.3f} ± {s['recall_sd']:.3f} | {s['f1']:.3f} ± {s['f1_sd']:.3f} | "
                     f"{s['iou']:.3f} ± {s['iou_sd']:.3f} |")
        lines.append(f"\nSegmentation network parameters: {s['params']:,}; training epochs: {s['epochs']}")
    isp = rd / "index_summary.json"
    if isp.exists():
        q = json.loads(isp.read_text())
        lines.append(f"Usable images after quality control: {q['usable']} of {q['images']} "
                     f"(excluded {q['too_small']} with sclera < {C.MIN_SCLERA_PIXELS} px)")

    df = load(rd, ignore_budget=a.smoke)  # smoke runs use a 2-epoch budget
    if df.empty:
        print("\n".join(lines) or "no results yet"); return

    lines.append("\n## Table 5. P1, mean ± SD over runs\n")
    lines.append("| Method | Params, M | Accuracy, % | Macro-F1 | EER, % | GAR at FAR = 0.1%, % | GAR at FAR = 1%, % | runs |")
    lines.append("|---|---|---|---|---|---|---|---|")
    for lab, m, i, t in T5:
        q = sel(df, "P1", m, i, t)
        prm = f"{q.params.iloc[0] / 1e6:.2f}" if len(q) and q.params.iloc[0] else "–"
        lines.append(f"| {lab} | {prm} | {ms(q.acc)} | {ms(q.f1, 3)} | {ms(q.eer)} | {ms(q.gar_far01)} | "
                     f"{ms(q.gar_far1)} | {len(q)} |")
        csv.append(dict(table=5, row=lab, acc=ms(q.acc), f1=ms(q.f1, 3), eer=ms(q.eer), gar01=ms(q.gar_far01)))

    lines.append("\n## Table 6. Ablation, P1, single run (seed 0)\n")
    lines.append("| Configuration | Accuracy, % | EER, % |")
    lines.append("|---|---|---|")
    for lab, m, i, t in T6:
        q = sel(df, "P1", m, i, t)
        q = q[q.seed == 0]
        f = lambda s, d=2: f"{s.iloc[0]:.{d}f}" if len(s) else "n/a"
        lines.append(f"| {lab} | {f(q.acc)} | {f(q.eer)} |")
        csv.append(dict(table=6, row=lab, acc=f(q.acc), eer=f(q.eer)))

    lines.append("\n## Table 8. P2 (cross-session), mean ± SD over runs\n")
    lines.append("| Training → test | Classes | RGB: accuracy, % | RGB: EER, % | E, V, M: accuracy, % | E, V, M: EER, % |")
    lines.append("|---|---|---|---|---|---|")
    acc_r, eer_r, acc_e, eer_e = [], [], [], []
    for lab, f in FOLDS:
        qr, qe = sel(df, "P2", "svcnn", "rgb", "", f), sel(df, "P2", "svcnn", "evm", "", f)
        k = int(qe.n_classes.iloc[0]) if len(qe) else (int(qr.n_classes.iloc[0]) if len(qr) else 0)
        lines.append(f"| {lab} | {k} | {ms(qr.acc)} | {ms(qr.eer)} | {ms(qe.acc)} | {ms(qe.eer)} |")
        if len(qr): acc_r.append(qr.acc.mean()); eer_r.append(qr.eer.mean())
        if len(qe): acc_e.append(qe.acc.mean()); eer_e.append(qe.eer.mean())
        csv.append(dict(table=8, row=lab, acc=ms(qr.acc), eer=ms(qr.eer), acc_evm=ms(qe.acc), eer_evm=ms(qe.eer)))
    g = lambda v: f"{np.mean(v):.2f}" if v else "n/a"
    lines.append(f"| Mean | | {g(acc_r)} | {g(eer_r)} | {g(acc_e)} | {g(eer_e)} |")

    full, rgb = sel(df, "P1", "svcnn", "evm", ""), sel(df, "P1", "svcnn", "rgb", "")
    lines.append("\n## Numbers for the text\n")
    if len(full):
        lines.append(f"- SV-CNN (E,V,M), P1: accuracy {ms(full.acc)} %, macro-F1 {full.f1.mean():.3f}, "
                     f"EER {full.eer.mean():.2f} %, GAR@FAR=0.1% {full.gar_far01.mean():.2f} %")
        lines.append(f"- P1: classes {int(full.n_classes.iloc[0])}, train/val/test {int(full.n_train.iloc[0])}/"
                     f"{int(full.n_val.iloc[0])}/{int(full.n_test.iloc[0])}, genuine/impostor "
                     f"{int(full.n_gen.iloc[0])}/{int(full.n_imp.iloc[0])}; SV-CNN parameters {int(full.params.iloc[0]):,}")
        lines.append(f"- Training epochs (mean): {full.epochs.mean():.0f}; time per run: {full.train_time_s.mean() / 60:.1f} min")
    if len(full) and len(rgb):
        lines.append(f"- Accuracy change E,V,M vs RGB (P1): {full.acc.mean() - rgb.acc.mean():+.2f} percentage points")
    if acc_e and acc_r:
        lines.append(f"- Mean cross-session accuracy change E,V,M vs RGB (P2): {np.mean(acc_e) - np.mean(acc_r):+.2f} pp")

    (rd / "tables.md").write_text("\n".join(lines), encoding="utf8")
    pd.DataFrame(csv).to_csv(rd / "tables.csv", index=False, encoding="utf-8-sig")
    print("\n".join(lines))
    draw_roc(rd)


def draw_roc(rd):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                         "font.size": 10, "axes.linewidth": 0.6})
    curves = [("LBP–SVM", "P1__lbp_svm__seed0", (0, (1, 1.5))), ("Shallow CNN", "P1__shallow_rgb__seed0", (0, (4, 2))),
              ("ResNet-18", "P1__resnet18_rgb__seed0", (0, (6, 2, 1, 2))),
              ("SV-CNN (RGB)", "P1__svcnn_rgb__seed0", (0, (2, 2))), ("SV-CNN (E, V, M)", "P1__svcnn_evm__seed0", "-")]
    fig, ax = plt.subplots(figsize=(12 / 2.54, 9 / 2.54), dpi=300)
    drawn = 0
    for lab, stem, ls in curves:
        p = rd / f"{stem}_scores.npz"
        if not p.exists():
            continue
        z = np.load(p)
        fpr, tpr, _ = roc_curve(z["genuine"], z["scores"])
        ax.plot(np.clip(fpr, 1e-5, 1) * 100, tpr * 100, ls=ls, color="black", lw=1.0, label=lab)
        drawn += 1
    if not drawn:
        plt.close(fig); return
    ax.set_xscale("log"); ax.set_xlim(1e-2, 100); ax.set_ylim(0, 101)
    ax.set_xlabel("FAR, %"); ax.set_ylabel("GAR, %")
    ax.grid(True, which="major", lw=0.3, color="0.8")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=3, frameon=False, handlelength=2.2, columnspacing=1.0)
    fig.tight_layout()
    fig.savefig(rd / "fig3_roc.png", dpi=300, bbox_inches="tight", pad_inches=0.04)
    print(f"\nFig. 3 saved to {rd / 'fig3_roc.png'}")


if __name__ == "__main__":
    main()
