"""Sclera segmentation (Section 2.2): U-Net with an ImageNet-pretrained ResNet-18 encoder,
trained on the manually annotated UBIRIS.v2 subset, evaluated on held-out annotated images
(Table 4) and then applied to every UBIRIS.v2 image.

  python seg.py              # train, evaluate, predict all masks into pred_masks/
  python seg.py --predict    # only predict with the saved model
"""
import argparse
import json
import random
import time

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

import config as C
import data

MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)


# ----------------------------------------------------------------------------
# Model
# ----------------------------------------------------------------------------
class Up(nn.Module):
    def __init__(self, cin, cskip, cout):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(cin + cskip, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))

    def forward(self, x, skip):
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.conv(torch.cat([x, skip], 1))


class UNetResNet18(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        import os
        from torchvision.models import resnet18, ResNet18_Weights
        if os.environ.get("SCLERA_NO_PRETRAINED"):  # offline testing only
            pretrained = False
        r = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        self.stem = nn.Sequential(r.conv1, r.bn1, r.relu)        # 1/2, 64
        self.pool = r.maxpool
        self.l1, self.l2, self.l3, self.l4 = r.layer1, r.layer2, r.layer3, r.layer4  # 1/4..1/32
        self.u3, self.u2, self.u1, self.u0 = Up(512, 256, 256), Up(256, 128, 128), Up(128, 64, 64), Up(64, 64, 64)
        self.head = nn.Sequential(nn.Conv2d(64, 32, 3, padding=1), nn.ReLU(inplace=True), nn.Conv2d(32, 1, 1))

    def forward(self, x):
        x0 = self.stem(x)
        x1 = self.l1(self.pool(x0))
        x2 = self.l2(x1)
        x3 = self.l3(x2)
        x4 = self.l4(x3)
        d = self.u0(self.u1(self.u2(self.u3(x4, x3), x2), x1), x0)
        d = F.interpolate(d, size=x.shape[-2:], mode="bilinear", align_corners=False)
        return self.head(d)


# ----------------------------------------------------------------------------
# Data
# ----------------------------------------------------------------------------
def to_tensor(img_bgr):
    x = cv2.resize(img_bgr, (C.SEG_W, C.SEG_H), interpolation=cv2.INTER_AREA)[:, :, ::-1].astype(np.float32) / 255
    return torch.from_numpy(((x - MEAN) / STD).transpose(2, 0, 1).copy())


class SegSet(Dataset):
    def __init__(self, pairs, train):
        self.pairs, self.train, self._rng = pairs, train, None

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, i):
        ip, mp = self.pairs[i]
        img = data.read_image(ip)
        m = data.read_mask(mp, img.shape)
        if self.train:
            if self._rng is None:
                info = torch.utils.data.get_worker_info()
                self._rng = random.Random(1234 + (info.id if info else 0))
            rng = self._rng
            if rng.random() < 0.5:
                img, m = img[:, ::-1].copy(), m[:, ::-1].copy()
            h, w = m.shape
            M = cv2.getRotationMatrix2D((w / 2, h / 2), rng.uniform(-10, 10), rng.uniform(0.9, 1.1))
            M[0, 2] += rng.uniform(-0.05, 0.05) * w; M[1, 2] += rng.uniform(-0.05, 0.05) * h
            img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            m = cv2.warpAffine(m, M, (w, h), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_REFLECT)
            f = img.astype(np.float32) * rng.uniform(0.8, 1.2) + rng.uniform(-20, 20)
            img = np.clip(f, 0, 255).astype(np.uint8)
            if rng.random() < 0.2:
                img = cv2.GaussianBlur(img, (0, 0), rng.uniform(0.3, 1.2))
        mt = cv2.resize(m, (C.SEG_W, C.SEG_H), interpolation=cv2.INTER_NEAREST)
        return to_tensor(img), torch.from_numpy(mt[None].astype(np.float32))


def split_annotated(pairs_by_key, seed=C.SPLIT_SEED):
    """Hold out whole eyes (classes) so that no eye is in both training and test parts."""
    keys = sorted(pairs_by_key)
    eyes = sorted({int(data.KEY.search(k)["cid"]) for k in keys})
    rng = random.Random(seed + 7)
    rng.shuffle(eyes)
    n_te = max(1, int(round(C.SEG_TEST_FRACTION * len(eyes))))
    n_va = max(1, int(round(C.SEG_VAL_FRACTION * len(eyes))))
    te_e, va_e = set(eyes[:n_te]), set(eyes[n_te:n_te + n_va])
    part = lambda S: [pairs_by_key[k] for k in keys if int(data.KEY.search(k)["cid"]) in S]
    tr_e = set(eyes) - te_e - va_e
    return part(tr_e), part(va_e), part(te_e)


# ----------------------------------------------------------------------------
# Post-processing and metrics
# ----------------------------------------------------------------------------
def postprocess(prob, thr=0.5, keep=2, min_frac=0.05):
    """Binary mask: closing, keep the (up to two) largest components, fill holes."""
    m = (prob >= thr).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m, 8)
    if n > 1:
        areas = stats[1:, cv2.CC_STAT_AREA]
        order = np.argsort(areas)[::-1][:keep]
        big = areas.max()
        out = np.zeros_like(m)
        for j in order:
            if areas[j] >= min_frac * big:
                out[lab == j + 1] = 1
        m = out
    # fill holes (e.g. specular reflections inside the sclera)
    inv = (1 - m).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(inv, 4)
    h, w = m.shape
    for j in range(1, n):
        x, y, bw, bh, _ = stats[j]
        if x > 0 and y > 0 and x + bw < w and y + bh < h:
            m[lab == j] = 1
    return m


def seg_metrics(pred, gt):
    tp = float((pred & gt).sum()); fp = float((pred & (1 - gt)).sum()); fn = float(((1 - pred) & gt).sum())
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    iou = tp / (tp + fp + fn) if tp + fp + fn else 0.0
    return p, r, f1, iou


@torch.no_grad()
def predict_prob(model, img_bgr, device, amp):
    x = to_tensor(img_bgr)[None].to(device)
    with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
        p = torch.sigmoid(model(x)).float()[0, 0].cpu().numpy()
    return cv2.resize(p, (img_bgr.shape[1], img_bgr.shape[0]), interpolation=cv2.INTER_LINEAR)


def evaluate_pairs(model, pairs, device, amp):
    rows = []
    for ip, mp in pairs:
        img = data.read_image(ip)
        rows.append(seg_metrics(postprocess(predict_prob(model, img, device, amp)), data.read_mask(mp, img.shape)))
    return np.array(rows)


def dice_loss(logits, target, eps=1.0):
    p = torch.sigmoid(logits)
    inter = (p * target).sum(dim=(1, 2, 3))
    return (1 - (2 * inter + eps) / (p.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + eps)).mean()


# ----------------------------------------------------------------------------
def train_and_evaluate(epochs, workers, device, amp):
    imgs, _ = data.scan_images()
    ann = data.scan_annotations()
    by_key = {r["key"]: (r["img"], ann[r["key"]]) for r in imgs if r["key"] in ann}
    if len(by_key) < 10:
        raise RuntimeError(f"Only {len(by_key)} annotated images matched UBIRIS.v2 files. Run check_dataset.py.")
    tr, va, te = split_annotated(by_key)
    print(f"Annotated images: {len(by_key)} -> train {len(tr)}, val {len(va)}, test {len(te)}")
    torch.manual_seed(0); random.seed(0); np.random.seed(0)
    model = UNetResNet18().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=C.SEG_LR, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=8)
    scaler = torch.amp.GradScaler(device.type, enabled=amp)
    bce = nn.BCEWithLogitsLoss()
    dl = DataLoader(SegSet(tr, True), batch_size=C.SEG_BATCH, shuffle=True, num_workers=workers,
                    persistent_workers=workers > 0, drop_last=len(tr) > C.SEG_BATCH)
    best, best_state, bad, t0 = -1.0, None, 0, time.time()
    for ep in range(1, epochs + 1):
        model.train(); tot = 0.0
        for x, y in dl:
            x, y = x.to(device), y.to(device)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
                out = model(x)
            loss = bce(out.float(), y) + dice_loss(out.float(), y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
            tot += loss.item() * len(x)
        model.eval()
        vf1 = float(np.mean(evaluate_pairs(model, va, device, amp)[:, 2]))
        sched.step(vf1)
        print(f"seg ep {ep:3d}  loss {tot / len(tr):.4f}  val F1 {vf1:.4f}  {time.time() - t0:5.0f}s", flush=True)
        if vf1 > best + 1e-5:
            best, best_state, bad = vf1, {k: v.detach().clone() for k, v in model.state_dict().items()}, 0
        else:
            bad += 1
            if bad >= C.SEG_STOP_PATIENCE:
                break
    model.load_state_dict(best_state)
    model.eval()
    rows = evaluate_pairs(model, te, device, amp)
    res = dict(n_annotated=len(by_key), n_train=len(tr), n_val=len(va), n_test=len(te), epochs=ep,
               train_time_s=time.time() - t0,
               precision=float(rows[:, 0].mean()), recall=float(rows[:, 1].mean()), f1=float(rows[:, 2].mean()),
               iou=float(rows[:, 3].mean()),
               precision_sd=float(rows[:, 0].std(ddof=1)), recall_sd=float(rows[:, 1].std(ddof=1)),
               f1_sd=float(rows[:, 2].std(ddof=1)), iou_sd=float(rows[:, 3].std(ddof=1)),
               params=sum(p.numel() for p in model.parameters()))
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (C.RESULTS_DIR / "seg_results.json").write_text(json.dumps(res, indent=1))
    torch.save(model.state_dict(), C.RESULTS_DIR / "seg_model.pt")
    print(f"SEG TEST  P {res['precision']:.4f}  R {res['recall']:.4f}  F1 {res['f1']:.4f}  IoU {res['iou']:.4f}")
    return model


def predict_all(model, device, amp):
    imgs, _ = data.scan_images()
    C.PRED_MASK_DIR.mkdir(parents=True, exist_ok=True)
    from tqdm import tqdm
    areas = []
    for r in tqdm(imgs, desc="predicting sclera masks"):
        out = C.PRED_MASK_DIR / f"{r['key']}.png"
        img = data.read_image(r["img"])
        m = postprocess(predict_prob(model, img, device, amp))
        data.write_png(out, m * 255)
        areas.append(int(m.sum()))
    areas = np.array(areas)
    print(f"masks written: {len(areas)}; sclera area px: median {np.median(areas):.0f}, "
          f"below MIN_SCLERA_PIXELS={C.MIN_SCLERA_PIXELS}: {(areas < C.MIN_SCLERA_PIXELS).sum()}")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--predict", action="store_true")
    ap.add_argument("--epochs", type=int, default=C.SEG_EPOCHS)
    ap.add_argument("--workers", type=int, default=C.NUM_WORKERS)
    a = ap.parse_args(argv)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    amp = C.USE_AMP and device.type == "cuda"
    if a.predict:
        model = UNetResNet18(pretrained=False).to(device)
        model.load_state_dict(torch.load(C.RESULTS_DIR / "seg_model.pt", map_location=device))
        model.eval()
    else:
        model = train_and_evaluate(a.epochs, a.workers, device, amp)
    predict_all(model, device, amp)
    if (C.RESULTS_DIR / "index.json").exists():
        (C.RESULTS_DIR / "index.json").unlink()  # rebuilt from the new masks
    if C.CACHE_DIR.exists():                     # region crops depend on the masks
        import shutil
        shutil.rmtree(C.CACHE_DIR, ignore_errors=True)


if __name__ == "__main__":
    main()
