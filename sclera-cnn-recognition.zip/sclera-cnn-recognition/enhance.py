"""GPU part of the input construction: Frangi vesselness (2)-(4), input tensor (5),
area downsampling to the network resolution and channel standardisation."""
import math

import torch
import torch.nn.functional as F

import config as C

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

_KERNELS = {}


def _gauss_kernels(sigma, device):
    key = (sigma, str(device))
    if key not in _KERNELS:
        r = int(math.ceil(3 * sigma))
        x = torch.arange(-r, r + 1, dtype=torch.float32, device=device)
        g = torch.exp(-x ** 2 / (2 * sigma ** 2))
        g = g / g.sum()
        g1 = -x / sigma ** 2 * g                       # first derivative of Gaussian
        g2 = (x ** 2 / sigma ** 4 - 1 / sigma ** 2) * g  # second derivative of Gaussian
        _KERNELS[key] = (g, g1, g2)
    return _KERNELS[key]


def _sep(img, kx, ky):
    """Separable filtering of B x 1 x H x W with kernel kx along W and ky along H (reflect padding)."""
    px, py = kx.numel() // 2, ky.numel() // 2
    img = F.conv2d(F.pad(img, (px, px, 0, 0), mode="reflect"), kx.view(1, 1, 1, -1))
    img = F.conv2d(F.pad(img, (0, 0, py, py), mode="reflect"), ky.view(1, 1, -1, 1))
    return img


@torch.no_grad()
def frangi_dark(E, sigmas=C.FRANGI_SIGMAS, beta=C.FRANGI_BETA, eps=1e-10):
    """Multiscale vesselness for dark tubular structures on a bright background.

    E: B x 1 x H x W float tensor in [0, 1]. Returns V in [0, 1] with the same shape.
    """
    V = torch.zeros_like(E)
    for s in sigmas:
        g, g1, g2 = _gauss_kernels(float(s), E.device)
        # F.conv2d is a correlation: the odd kernel g1 changes sign, but Hxy uses it twice.
        hxx = _sep(E, g2, g) * s ** 2
        hyy = _sep(E, g, g2) * s ** 2
        hxy = _sep(E, g1, g1) * s ** 2
        tmp = torch.sqrt((hxx - hyy) ** 2 + 4 * hxy ** 2)
        mu1 = 0.5 * (hxx + hyy + tmp)
        mu2 = 0.5 * (hxx + hyy - tmp)
        swap = mu1.abs() > mu2.abs()
        lam1 = torch.where(swap, mu2, mu1)   # |lam1| <= |lam2|
        lam2 = torch.where(swap, mu1, mu2)
        rb2 = (lam1 / (lam2.abs() + eps)) ** 2
        s2 = lam1 ** 2 + lam2 ** 2
        c = 0.5 * torch.sqrt(s2).amax(dim=(2, 3), keepdim=True) + eps
        v = torch.exp(-rb2 / (2 * beta ** 2)) * (1 - torch.exp(-s2 / (2 * c ** 2)))
        v = torch.where(lam2 < 0, torch.zeros_like(v), v)
        V = torch.maximum(V, v)
    V = V / (V.amax(dim=(2, 3), keepdim=True) + eps)
    return V


@torch.no_grad()
def build_input(x_u8, m_u8, mode):
    """x_u8: B x C x 384 x 768 uint8 on GPU, m_u8: B x 1 x 384 x 768 uint8 {0,1}.

    Returns the un-standardised network input at 192 x 384:
      'rgb' -> RGB * M (3 ch); 'e' -> E * M; 'ev' -> [E*M, V*M]; 'evm' -> [E*M, V*M, M].
    """
    m = m_u8.float()
    x = x_u8.float() / 255.0
    if mode == "rgb":
        out = x * m
    else:
        if mode == "e":
            out = x * m
        else:
            v = frangi_dark(x)
            chans = [x * m, v * m] + ([m] if mode == "evm" else [])
            out = torch.cat(chans, dim=1)
    return F.avg_pool2d(out, 2)  # area interpolation 384x768 -> 192x384


def in_channels(mode):
    return {"rgb": 3, "e": 1, "ev": 2, "evm": 3}[mode]


class Standardizer:
    def __init__(self, mean, std, device):
        self.mean = torch.tensor(mean, dtype=torch.float32, device=device).view(1, -1, 1, 1)
        self.std = torch.tensor(std, dtype=torch.float32, device=device).view(1, -1, 1, 1)

    def __call__(self, x):
        return (x - self.mean) / self.std

    @classmethod
    def imagenet(cls, device):
        return cls(IMAGENET_MEAN, IMAGENET_STD, device)

    @classmethod
    def from_loader(cls, loader, mode, device):
        """Per-channel mean and std of the network input over the (non-augmented) training set."""
        s = s2 = n = 0
        for x, m, _ in loader:
            xin = build_input(x.to(device, non_blocking=True), m.to(device, non_blocking=True), mode).double()
            s = s + xin.sum(dim=(0, 2, 3))
            s2 = s2 + (xin ** 2).sum(dim=(0, 2, 3))
            n += xin.numel() // xin.shape[1]
        mean = s / n
        std = torch.sqrt(torch.clamp(s2 / n - mean ** 2, min=1e-12))
        return cls(mean.tolist(), std.tolist(), device)
