"""Additional experiments of the manuscript (run after run_all.py).

Block A (seed 0, ~6 h with NUM_WORKERS = 2):
  - ResNet-18, RGB, cross-session protocol P2 (both directions)        -> Table 8
  - ResNet-18 pre-trained on ImageNet with the E, V, M input, P1       -> extends Table 5
Block B (seed 0, ~10-16 h):
  - SV-CNN without dropout, training budget 150 epochs (early stopping still active),
    RGB and E, V, M inputs, P1                                         -> Table 7
Block C (seeds 1 and 2, ~11 h):
  - the runs of block A with the remaining seeds (mean ± SD as in Tables 5 and 7)

Finished runs are skipped, so the script can be interrupted and restarted at any time.

  python run_extra.py              # blocks A, B, C in this order
  python run_extra.py --block A    # only block A
  python make_extra.py             # tables and figure from whatever has finished
"""
import argparse
import time

import config as C
import train

LONG_EPOCHS = 150


def jobs(block, seeds=(0, 1, 2)):
    def resnet_p2(s):
        return [["--protocol", "P2", "--fold", f, "--model", "resnet18", "--input", "rgb", "--seed", str(s)]
                for f in ("12", "21")]

    def resnet_evm(s):
        return [["--protocol", "P1", "--model", "resnet18", "--input", "evm", "--seed", str(s)]]

    def long_svcnn():
        return [["--protocol", "P1", "--model", "svcnn", "--input", i, "--no-dropout",
                 "--epochs", str(LONG_EPOCHS), "--seed", "0"] for i in ("rgb", "evm")]

    out = []
    if block in ("A", "all"):
        out += resnet_p2(seeds[0]) + resnet_evm(seeds[0])
    if block in ("B", "all"):
        out += long_svcnn()
    if block in ("C", "all"):
        for s in seeds[1:]:
            out += resnet_p2(s) + resnet_evm(s)
    return out


def names(block="all"):
    """Run names of the jobs (used for the progress report in the notebook)."""
    ap = argparse.ArgumentParser()
    for k in ["--model", "--input", "--protocol", "--fold", "--seed", "--epochs"]:
        ap.add_argument(k)
    for k in ["--no-bn", "--no-dropout", "--no-aug"]:
        ap.add_argument(k, action="store_true")
    out = []
    for j in jobs(block, C.SEEDS):
        a = ap.parse_args(j)
        a.epochs = int(a.epochs) if a.epochs else C.MAX_EPOCHS
        out.append(train.run_name(a))
    return out


def status(block="all"):
    done = {p.stem for p in C.RESULTS_DIR.glob("P*.json")}
    todo = names(block)
    for n in todo:
        print(("  [done] " if n in done else "  [todo] ") + n)
    print(f"done {sum(n in done for n in todo)} of {len(todo)}")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", choices=["A", "B", "C", "all"], default="all")
    ap.add_argument("--workers", type=int, default=C.NUM_WORKERS)
    a = ap.parse_args(argv)
    todo = jobs(a.block, C.SEEDS)
    t0 = time.time()
    for k, j in enumerate(todo, 1):
        print(f"\n##### extra job {k}/{len(todo)}  (elapsed {(time.time() - t0) / 3600:.2f} h)")
        train.main(j + ["--workers", str(a.workers)])
    print(f"\nBlock {a.block} done in {(time.time() - t0) / 3600:.2f} h. Now run: python make_extra.py")


if __name__ == "__main__":
    main()
