## Table 4. Sclera segmentation on held-out annotated images (mean ± SD over images)

| Images (train / val / test) | Precision | Recall | F1-score | IoU |
|---|---|---|---|---|
| 489 / 65 / 129 | 0.919 ± 0.046 | 0.942 ± 0.059 | 0.928 ± 0.035 | 0.868 ± 0.058 |

Segmentation network parameters: 14,404,225; training epochs: 56
Usable images after quality control: 10919 of 11101 (excluded 182 with sclera < 1000 px)

## Table 5. P1, mean ± SD over runs

| Method | Params, M | Accuracy, % | Macro-F1 | EER, % | GAR at FAR = 0.1%, % | GAR at FAR = 1%, % | runs |
|---|---|---|---|---|---|---|---|
| LBP–SVM | – | 8.40 ± 0.00 | 0.074 ± 0.000 | 45.57 ± 0.00 | 1.77 ± 0.00 | 8.04 ± 0.00 | 1 |
| Shallow CNN | 47.56 | 40.69 ± 4.55 | 0.375 ± 0.042 | 38.46 ± 1.47 | 5.48 ± 0.70 | 13.72 ± 1.88 | 3 |
| ResNet-18 | 11.44 | 95.10 ± 0.36 | 0.943 ± 0.004 | 2.63 ± 0.08 | 81.92 ± 1.85 | 94.46 ± 0.24 | 3 |
| SV-CNN (RGB) | 1.37 | 59.85 ± 5.74 | 0.576 ± 0.057 | 20.45 ± 0.78 | 13.92 ± 1.98 | 33.22 ± 3.34 | 3 |
| SV-CNN (E, V, M) | 1.37 | 52.36 ± 0.42 | 0.497 ± 0.006 | 24.14 ± 0.85 | 10.09 ± 0.48 | 26.56 ± 0.62 | 3 |

## Table 6. Ablation, P1, single run (seed 0)

| Configuration | Accuracy, % | EER, % |
|---|---|---|
| Input: RGB | 57.22 | 20.49 |
| Input: E (one channel) | 60.85 | 22.55 |
| Input: E, V | 52.54 | 23.75 |
| Input: E, V, M (full model) | 52.45 | 24.97 |
| Full model without batch normalization | 0.32 | 50.00 |
| Full model without dropout | 79.29 | 22.43 |
| Full model without data augmentation | 51.86 | 22.77 |

## Table 8. P2 (cross-session), mean ± SD over runs

| Training → test | Classes | RGB: accuracy, % | RGB: EER, % | E, V, M: accuracy, % | E, V, M: EER, % |
|---|---|---|---|---|---|
| S1 → S2 | 222 | 21.45 ± 1.93 | 21.32 ± 1.19 | 17.27 ± 0.62 | 26.61 ± 0.57 |
| S2 → S1 | 222 | 19.00 ± 1.35 | 20.59 ± 1.40 | 17.89 ± 0.64 | 24.96 ± 1.60 |
| Mean | | 20.23 | 20.95 | 17.58 | 25.78 |

## Numbers for the text

- SV-CNN (E,V,M), P1: accuracy 52.36 ± 0.42 %, macro-F1 0.497, EER 24.14 %, GAR@FAR=0.1% 10.09 %
- P1: classes 516, train/val/test 7346/1371/2202, genuine/impostor 4181/2419120; SV-CNN parameters 1,372,132
- Training epochs (mean): 60; time per run: 171.6 min
- Accuracy change E,V,M vs RGB (P1): -7.49 percentage points
- Mean cross-session accuracy change E,V,M vs RGB (P2): -2.65 pp