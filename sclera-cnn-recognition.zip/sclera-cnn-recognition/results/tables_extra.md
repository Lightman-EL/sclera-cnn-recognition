## Table 5 (extended). P1, mean ± SD over runs

| Method | Input | Accuracy, % | Macro-F1 | EER, % | GAR at FAR = 0.1%, % | GAR at FAR = 1%, % | best epoch | runs |
|---|---|---|---|---|---|---|---|---|
| ResNet-18 | RGB | 95.10 ± 0.36 | 0.943 ± 0.004 | 2.63 ± 0.08 | 81.92 ± 1.85 | 94.46 ± 0.24 | 55, 36, 50 | 3 |
| ResNet-18 | E, V, M | 87.62 ± 0.71 | 0.863 ± 0.008 | 6.30 ± 0.47 | 56.82 ± 3.34 | 80.70 ± 2.69 | 55, 55, 37 | 3 |
| SV-CNN | RGB | 59.85 ± 5.74 | 0.576 ± 0.057 | 20.45 ± 0.78 | 13.92 ± 1.98 | 33.22 ± 3.34 | 60, 59, 59 | 3 |
| SV-CNN | E, V, M | 52.36 ± 0.42 | 0.497 ± 0.006 | 24.14 ± 0.85 | 10.09 ± 0.48 | 26.56 ± 0.62 | 58, 58, 57 | 3 |

## Table 8 (with ResNet-18). P2 (cross-session), mean ± SD over runs

| Training → test | Classes | SV-CNN RGB: acc, % | SV-CNN RGB: EER, % | SV-CNN E,V,M: acc, % | SV-CNN E,V,M: EER, % | ResNet-18 RGB: acc, % | ResNet-18 RGB: EER, % | ResNet runs |
|---|---|---|---|---|---|---|---|---|
| S1 → S2 | 222 | 21.45 ± 1.93 | 21.32 ± 1.19 | 17.27 ± 0.62 | 26.61 ± 0.57 | 64.61 ± 1.56 | 8.58 ± 0.46 | 3 |
| S2 → S1 | 222 | 19.00 ± 1.35 | 20.59 ± 1.40 | 17.89 ± 0.64 | 24.96 ± 1.60 | 67.95 ± 1.64 | 8.30 ± 0.65 | 3 |
| Mean | | 20.23 | 20.95 | 17.58 | 25.78 | 66.28 | 8.44 | |

## Table 7. SV-CNN trained longer, P1, seed 0

| Configuration | Budget, epochs | Epochs run | Best epoch | Accuracy, % | Macro-F1 | EER, % | GAR at FAR = 0.1%, % | Training time, h |
|---|---|---|---|---|---|---|---|---|
| SV-CNN, RGB, dropout 0.5 | 60 | 60 | 60 | 57.22 | 0.548 | 20.49 | 14.09 | 1.8 |
| SV-CNN, E,V,M, dropout 0.5 | 60 | 60 | 58 | 52.45 | 0.491 | 24.97 | 10.48 | 1.9 |
| SV-CNN, E,V,M, no dropout | 60 | 60 | 59 | 79.29 | 0.775 | 22.43 | 18.99 | 3.4 |
| SV-CNN, RGB, no dropout | 150 | 150 | 143 | 86.97 | 0.855 | 17.33 | 26.02 | 8.1 |
| SV-CNN, E,V,M, no dropout | 150 | 150 | 140 | 81.74 | 0.798 | 19.95 | 22.77 | 8.4 |

## Details of the additional runs

| Run | Epochs run | Best epoch | Early stop | Val. acc. at best epoch, % | Test acc., % | EER, % | Time, min |
|---|---|---|---|---|---|---|---|
| P1__resnet18_evm__seed0 | 60 | 55 | no | 88.3 | 87.69 | 6.08 | 200 |
| P1__resnet18_evm__seed1 | 60 | 55 | no | 89.2 | 88.28 | 5.98 | 202 |
| P1__resnet18_evm__seed2 | 49 | 37 | yes | 88.9 | 86.88 | 6.84 | 204 |
| P1__svcnn_evm_nodrop_ep150__seed0 | 150 | 140 | no | 83.2 | 81.74 | 19.95 | 503 |
| P1__svcnn_rgb_nodrop_ep150__seed0 | 150 | 143 | no | 87.5 | 86.97 | 17.33 | 486 |
| P2__12__resnet18_rgb__seed0 | 60 | 54 | no | 96.8 | 64.11 | 9.07 | 47 |
| P2__12__resnet18_rgb__seed1 | 53 | 41 | yes | 96.6 | 63.36 | 8.51 | 66 |
| P2__12__resnet18_rgb__seed2 | 60 | 58 | no | 98.2 | 66.35 | 8.16 | 74 |
| P2__21__resnet18_rgb__seed0 | 60 | 55 | no | 95.5 | 67.72 | 8.40 | 74 |
| P2__21__resnet18_rgb__seed1 | 60 | 52 | no | 95.5 | 66.44 | 8.90 | 73 |
| P2__21__resnet18_rgb__seed2 | 60 | 60 | no | 95.7 | 69.69 | 7.61 | 75 |

## Numbers for the text

- ResNet-18, P1: E,V,M vs RGB accuracy -7.48 pp, EER +3.67 pp (runs: 3 vs 3)
- ResNet-18 RGB: P1 accuracy 95.10 % -> P2 mean 66.28 % (-28.82 pp); EER 2.63 % -> 8.44 %
- P2 mean accuracy: ResNet-18 RGB 66.28 % vs SV-CNN RGB 20.23 %
- Longer training without dropout: E,V,M vs RGB accuracy -5.22 pp, EER +2.61 pp
- P2 ResNet-18: classes 222, train/val/test per fold as in Table 3