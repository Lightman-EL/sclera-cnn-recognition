"""Tables and figures for the additional experiments of run_extra.py.

  python make_extra.py   -> results/tables_extra.md, results/fig3_roc_extra.png, results/fig4_curves.png
Works with partial results: missing runs are shown as n/a.
"""
import json

import numpy as np
import pandas as pd

import config as C
from make_tables import load, ms, sel
from run_extra import LONG_EPOCHS

FOLDS = [("S1 → S2", "12"), ("S2 → S1", "21")]
LONG = f"_nodrop_ep{LONG_EPOCHS}"


def history(rd, name):
    p = rd / f"{name}.json"
    return json.loads(p.read_text()).get("history", []) if p.exists() else []


def val_acc_at_best(rd, name):
    h = history(rd, name)
    return min(h, key=lambda x: x["val_loss"])["val_acc"] if h else float("nan")


def best_ep(rd, r):
    """Best epoch of a run: stored by the new train.py, recovered from the history for older runs."""
    if "best_epoch" in r and pd.notna(r["best_epoch"]):
        return int(r["best_epoch"])
    h = history(rd, r["name"])
    return min(h, key=lambda x: x["val_loss"])["epoch"] if h else None


def main(argv=None):
    rd = C.RESULTS_DIR
    df = load(rd)
    L = []
    f1 = lambda s, d=2: f"{s.iloc[0]:.{d}f}" if len(s) else "n/a"

    # ------------------------------------------------------------------ Table 5, extended
    L.append("## Table 5 (extended). P1, mean ± SD over runs\n")
    L.append("| Method | Input | Accuracy, % | Macro-F1 | EER, % | GAR at FAR = 0.1%, % | GAR at FAR = 1%, % | best epoch | runs |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for lab, m, i in [("ResNet-18", "resnet18", "rgb"), ("ResNet-18", "resnet18", "evm"),
                      ("SV-CNN", "svcnn", "rgb"), ("SV-CNN", "svcnn", "evm")]:
        q = sel(df, "P1", m, i, "")
        be = ", ".join(str(best_ep(rd, r)) for _, r in q.sort_values("seed").iterrows()) or "–"
        L.append(f"| {lab} | {i.upper() if i == 'rgb' else 'E, V, M'} | {ms(q.acc)} | {ms(q.f1, 3)} | {ms(q.eer)} | "
                 f"{ms(q.gar_far01)} | {ms(q.gar_far1)} | {be} | {len(q)} |")

    # ------------------------------------------------------------------ Table 8, with ResNet-18
    L.append("\n## Table 8 (with ResNet-18). P2 (cross-session), mean ± SD over runs\n")
    L.append("| Training → test | Classes | SV-CNN RGB: acc, % | SV-CNN RGB: EER, % | SV-CNN E,V,M: acc, % | "
             "SV-CNN E,V,M: EER, % | ResNet-18 RGB: acc, % | ResNet-18 RGB: EER, % | ResNet runs |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    means = {k: [] for k in ["ar", "er", "ae", "ee", "an", "en"]}
    for lab, f in FOLDS:
        qr, qe, qn = (sel(df, "P2", "svcnn", "rgb", "", f), sel(df, "P2", "svcnn", "evm", "", f),
                      sel(df, "P2", "resnet18", "rgb", "", f))
        k = next((int(q.n_classes.iloc[0]) for q in (qn, qr, qe) if len(q)), 0)
        L.append(f"| {lab} | {k} | {ms(qr.acc)} | {ms(qr.eer)} | {ms(qe.acc)} | {ms(qe.eer)} | "
                 f"{ms(qn.acc)} | {ms(qn.eer)} | {len(qn)} |")
        for key, q, col in [("ar", qr, "acc"), ("er", qr, "eer"), ("ae", qe, "acc"), ("ee", qe, "eer"),
                            ("an", qn, "acc"), ("en", qn, "eer")]:
            if len(q):
                means[key].append(q[col].mean())
    g = lambda v: f"{np.mean(v):.2f}" if v else "n/a"
    L.append(f"| Mean | | {g(means['ar'])} | {g(means['er'])} | {g(means['ae'])} | {g(means['ee'])} | "
             f"{g(means['an'])} | {g(means['en'])} | |")

    # ------------------------------------------------------------------ Longer training
    L.append("\n## Table 7. SV-CNN trained longer, P1, seed 0\n")
    L.append("| Configuration | Budget, epochs | Epochs run | Best epoch | Accuracy, % | Macro-F1 | EER, % | "
             "GAR at FAR = 0.1%, % | Training time, h |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    rows = [("SV-CNN, RGB, dropout 0.5", "svcnn", "rgb", ""),
            ("SV-CNN, E,V,M, dropout 0.5", "svcnn", "evm", ""),
            ("SV-CNN, E,V,M, no dropout", "svcnn", "evm", "_nodrop"),
            ("SV-CNN, RGB, no dropout", "svcnn", "rgb", LONG),
            ("SV-CNN, E,V,M, no dropout", "svcnn", "evm", LONG)]
    for lab, m, i, t in rows:
        q = sel(df, "P1", m, i, t)
        q = q[q.seed == 0]
        budget = LONG_EPOCHS if t == LONG else C.MAX_EPOCHS
        be = str(best_ep(rd, q.iloc[0])) if len(q) else "–"
        tt = f"{q.train_time_s.iloc[0] / 3600:.1f}" if len(q) else "n/a"
        L.append(f"| {lab} | {budget} | {f1(q.epochs, 0)} | {be} | {f1(q.acc)} | {f1(q.f1, 3)} | {f1(q.eer)} | "
                 f"{f1(q.gar_far01)} | {tt} |")

    # ------------------------------------------------------------------ Run details
    L.append("\n## Details of the additional runs\n")
    L.append("| Run | Epochs run | Best epoch | Early stop | Val. acc. at best epoch, % | Test acc., % | EER, % | Time, min |")
    L.append("|---|---|---|---|---|---|---|---|")
    extra = df[(df.model == "resnet18") & ((df.protocol == "P2") | (df.input == "evm"))]
    extra = pd.concat([extra, df[df.variant.str.endswith(LONG)]])
    for _, r in extra.sort_values("name").iterrows():
        L.append(f"| {r['name']} | {int(r.epochs)} | {best_ep(rd, r)} | "
                 f"{'yes' if r.get('early_stopped') else 'no'} | {val_acc_at_best(rd, r['name']):.1f} | {r.acc:.2f} | "
                 f"{r.eer:.2f} | {r.train_time_s / 60:.0f} |")

    # ------------------------------------------------------------------ Numbers for the text
    L.append("\n## Numbers for the text\n")
    rr, re_ = sel(df, "P1", "resnet18", "rgb", ""), sel(df, "P1", "resnet18", "evm", "")
    if len(rr) and len(re_):
        L.append(f"- ResNet-18, P1: E,V,M vs RGB accuracy {re_.acc.mean() - rr.acc.mean():+.2f} pp, "
                 f"EER {re_.eer.mean() - rr.eer.mean():+.2f} pp (runs: {len(re_)} vs {len(rr)})")
    if means["an"] and len(rr):
        L.append(f"- ResNet-18 RGB: P1 accuracy {rr.acc.mean():.2f} % -> P2 mean {np.mean(means['an']):.2f} % "
                 f"({np.mean(means['an']) - rr.acc.mean():+.2f} pp); EER {rr.eer.mean():.2f} % -> {np.mean(means['en']):.2f} %")
    if means["an"] and means["ar"]:
        L.append(f"- P2 mean accuracy: ResNet-18 RGB {np.mean(means['an']):.2f} % vs SV-CNN RGB {np.mean(means['ar']):.2f} %")
    lr_, le_ = sel(df, "P1", "svcnn", "rgb", LONG), sel(df, "P1", "svcnn", "evm", LONG)
    if len(lr_) and len(le_):
        L.append(f"- Longer training without dropout: E,V,M vs RGB accuracy {le_.acc.iloc[0] - lr_.acc.iloc[0]:+.2f} pp, "
                 f"EER {le_.eer.iloc[0] - lr_.eer.iloc[0]:+.2f} pp")
    qn = sel(df, "P2", "resnet18", "rgb", "")
    if len(qn):
        L.append(f"- P2 ResNet-18: classes {int(qn.n_classes.iloc[0])}, train/val/test per fold as in Table 3")

    out = "\n".join(L)
    (rd / "tables_extra.md").write_text(out, encoding="utf8")
    print(out)
    draw_roc_extra(rd)
    draw_curves(rd)


def _style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                         "font.size": 10, "axes.linewidth": 0.6})
    return plt


def draw_roc_extra(rd):
    from sklearn.metrics import roc_curve
    plt = _style()
    curves = [("LBP–SVM", "P1__lbp_svm__seed0", (0, (1, 1.5)), "black"),
              ("Shallow CNN", "P1__shallow_rgb__seed0", (0, (4, 2)), "black"),
              ("ResNet-18 (RGB)", "P1__resnet18_rgb__seed0", (0, (6, 2, 1, 2)), "black"),
              ("ResNet-18 (E, V, M)", "P1__resnet18_evm__seed0", "-", "0.55"),
              ("SV-CNN (RGB)", "P1__svcnn_rgb__seed0", (0, (2, 2)), "black"),
              ("SV-CNN (E, V, M)", "P1__svcnn_evm__seed0", "-", "black")]
    fig, ax = plt.subplots(figsize=(12 / 2.54, 9 / 2.54), dpi=300)
    drawn = 0
    for lab, stem, ls, col in curves:
        p = rd / f"{stem}_scores.npz"
        if not p.exists():
            continue
        drawn += 1
        z = np.load(p)
        fpr, tpr, _ = roc_curve(z["genuine"], z["scores"])
        ax.plot(np.clip(fpr, 1e-5, 1) * 100, tpr * 100, ls=ls, color=col, lw=1.0 if col == "black" else 1.6, label=lab)
    if not drawn:
        plt.close(fig); return
    ax.set_xscale("log"); ax.set_xlim(1e-2, 100); ax.set_ylim(0, 101)
    ax.set_xlabel("FAR, %"); ax.set_ylabel("GAR, %")
    ax.grid(True, which="major", lw=0.3, color="0.8")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=3, frameon=False, handlelength=2.2, columnspacing=1.0)
    fig.tight_layout()
    fig.savefig(rd / "fig3_roc_extra.png", dpi=300, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)


def draw_curves(rd):
    """Validation accuracy per epoch (P1, seed 0): the effect of the training budget and of dropout."""
    plt = _style()
    curves = [("SV-CNN, RGB, dropout", "P1__svcnn_rgb__seed0", (0, (2, 2)), "black"),
              ("SV-CNN, E, V, M, dropout", "P1__svcnn_evm__seed0", "-", "black"),
              ("SV-CNN, RGB, no dropout", f"P1__svcnn_rgb{LONG}__seed0", (0, (2, 2)), "0.55"),
              ("SV-CNN, E, V, M, no dropout", f"P1__svcnn_evm{LONG}__seed0", "-", "0.55"),
              ("ResNet-18, RGB", "P1__resnet18_rgb__seed0", (0, (6, 2, 1, 2)), "black")]
    fig, ax = plt.subplots(figsize=(12 / 2.54, 8 / 2.54), dpi=300)
    drawn = 0
    for lab, stem, ls, col in curves:
        h = history(rd, stem)
        if not h:
            continue
        ax.plot([x["epoch"] for x in h], [x["val_acc"] for x in h], ls=ls, color=col,
                lw=1.0 if col == "black" else 1.6, label=lab)
        drawn += 1
    if not drawn:
        plt.close(fig); return
    ax.axvline(C.MAX_EPOCHS, color="0.7", lw=0.6)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Validation accuracy, %"); ax.set_ylim(0, 100)
    ax.grid(True, lw=0.3, color="0.85")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, frameon=False, handlelength=2.2)
    fig.tight_layout()
    fig.savefig(rd / "fig4_curves.png", dpi=300, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)


if __name__ == "__main__":
    main()
