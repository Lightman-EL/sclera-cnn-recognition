"""LBP-SVM baseline (Section 2.8): uniform rotation-invariant LBP (P=8, R=1) histograms
in a 4 x 8 grid on the enhanced green channel E inside the sclera, linear SVM for
identification, chi-square distance for verification."""
import json
import time

import cv2
import numpy as np
from skimage.feature import local_binary_pattern
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

import config as C
import data
import metrics

GRID = (4, 8)
P, R = 8, 1
NBINS = P + 2


def lbp_feature(rec):
    img, msk = data.load_cached(rec["key"])
    E = data.clahe_green(img)
    E = cv2.resize(E, (C.NET_W, C.NET_H), interpolation=cv2.INTER_AREA)
    m = cv2.resize(msk.astype(np.float32), (C.NET_W, C.NET_H), interpolation=cv2.INTER_AREA) >= 0.5
    codes = local_binary_pattern(E, P, R, method="uniform").astype(np.int32)
    gh, gw = C.NET_H // GRID[0], C.NET_W // GRID[1]
    feats = []
    for i in range(GRID[0]):
        for j in range(GRID[1]):
            c = codes[i * gh:(i + 1) * gh, j * gw:(j + 1) * gw]
            mm = m[i * gh:(i + 1) * gh, j * gw:(j + 1) * gw]
            h = np.bincount(c[mm], minlength=NBINS).astype(np.float64)
            feats.append(h / h.sum() if h.sum() > 0 else h)
    return np.concatenate(feats)


def _fit_binary(X, yb):
    """One class of the one-vs-rest linear SVM (squared hinge loss, L2 regularisation, C = 1)."""
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        m = LinearSVC(C=1.0, dual=False, tol=1e-3, max_iter=1000).fit(X, yb)
    return m.coef_[0].copy(), float(m.intercept_[0])


def cached_features(recs):
    """LBP features are computed once and stored in CACHE_DIR/lbp_features.npz."""
    from tqdm import tqdm
    path = C.CACHE_DIR / "lbp_features.npz"
    feats = {}
    if path.exists():
        z = np.load(path)
        feats = dict(zip(z["keys"].tolist(), z["X"]))
    todo = [r for r in recs if r["key"] not in feats]
    for r in tqdm(todo, desc="LBP features"):
        feats[r["key"]] = lbp_feature(r)
    if todo:
        keys = sorted(feats)
        np.savez_compressed(path, keys=np.array(keys), X=np.stack([feats[k] for k in keys]))
    return feats


def chi2_similarity(F):
    n = len(F)
    S = np.zeros((n, n), np.float32)
    for i in range(n):
        d = 0.5 * (((F[i] - F) ** 2) / (F[i] + F + 1e-10)).sum(axis=1)
        S[i] = -d
    return S


def run(records, tr, va, te, tag="P1"):
    t0 = time.time()
    # trained on the same training images as the CNNs (no hyper-parameter search on va)
    labels = data.label_map(records, tr)
    te = [i for i in te if records[i]["cid"] in labels]
    feats = cached_features([records[i] for i in tr + te])
    Xtr = np.stack([feats[records[i]["key"]] for i in tr])
    ytr = np.array([labels[records[i]["cid"]] for i in tr])
    Xte = np.stack([feats[records[i]["key"]] for i in te])
    yte = np.array([labels[records[i]["cid"]] for i in te])
    sc = StandardScaler().fit(Xtr)
    Xtr_s, Xte_s = sc.transform(Xtr), sc.transform(Xte)
    K = len(labels)
    print(f"training one-vs-rest linear SVM: {len(tr)} images, {K} classes, all CPU cores "
          f"(progress lines 'Done N tasks' below)...", flush=True)
    t1 = time.time()
    from joblib import Parallel, delayed
    models = Parallel(n_jobs=-1, verbose=5)(
        delayed(_fit_binary)(Xtr_s, (ytr == c).astype(np.int8)) for c in range(K))
    W = np.stack([m[0] for m in models]); b = np.array([m[1] for m in models])
    print(f"SVM trained in {time.time() - t1:.0f} s", flush=True)
    res = metrics.identification(yte, (Xte_s @ W.T + b).argmax(1))
    scores, gen = metrics.all_pairs(chi2_similarity(Xte), yte)
    res.update(metrics.verification(scores, gen))
    res.update(name="lbp_svm", model="lbp_svm", input="e", protocol=tag, fold=None, seed=0,
               params=0, epochs=0, train_time_s=time.time() - t0, n_train=len(tr), n_test=len(te),
               n_classes=len(labels))
    return res, scores, gen


if __name__ == "__main__":
    recs = data.load_index()
    data.build_cache(recs)
    tr, va, te = data.split_p1(recs)
    res, scores, gen = run(recs, tr, va, te)
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (C.RESULTS_DIR / "P1__lbp_svm__seed0.json").write_text(json.dumps(res, indent=1))
    np.savez_compressed(C.RESULTS_DIR / "P1__lbp_svm__seed0_scores.npz", scores=scores, genuine=gen)
    print(json.dumps(res, indent=1))
