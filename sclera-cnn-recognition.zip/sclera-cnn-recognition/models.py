"""SV-CNN (Table 2) and the two CNN baselines (Section 2.8). Every model returns (logits, embedding)."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class SVCNN(nn.Module):
    def __init__(self, in_ch=3, n_classes=110, bn=True, dropout=0.5):
        super().__init__()
        layers, c = [], in_ch
        for out in (32, 64, 128, 256):
            for _ in range(2):
                layers.append(nn.Conv2d(c, out, 3, 1, 1, bias=not bn))
                if bn:
                    layers.append(nn.BatchNorm2d(out))
                layers.append(nn.ReLU(inplace=True))
                c = out
            layers.append(nn.MaxPool2d(2, 2))
        self.features = nn.Sequential(*layers)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.fc1 = nn.Linear(256, 256)
        self.bn1 = nn.BatchNorm1d(256) if bn else nn.Identity()
        self.fc2 = nn.Linear(256, n_classes)
        for mod in self.modules():
            if isinstance(mod, nn.Conv2d):
                nn.init.kaiming_normal_(mod.weight, mode="fan_out", nonlinearity="relu")
                if mod.bias is not None:
                    nn.init.zeros_(mod.bias)

    def forward(self, x):
        g = self.gap(self.features(x)).flatten(1)
        e = self.bn1(self.fc1(self.drop(g)))   # embedding = FC1 output after BN (before ReLU)
        return self.fc2(F.relu(e)), e


class ShallowCNN(nn.Module):
    """Re-implementation of the four-layer CNN of Maheshan et al. for a 192 x 384 x 3 input."""

    def __init__(self, in_ch=3, n_classes=110, h=192, w=384):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_ch, 10, 3, 1, 1), nn.ReLU(inplace=True),
            nn.Conv2d(10, 20, 3, 1, 1), nn.ReLU(inplace=True), nn.MaxPool2d(2, 2),
            nn.Conv2d(20, 10, 3, 1, 1), nn.ReLU(inplace=True),
            nn.Conv2d(10, 20, 3, 1, 1), nn.ReLU(inplace=True), nn.MaxPool2d(2, 2))
        self.fc = nn.Linear(20 * (h // 4) * (w // 4), n_classes)

    def forward(self, x):
        f = self.features(x).flatten(1)
        return self.fc(f), f


class ResNet18(nn.Module):
    def __init__(self, n_classes=110, pretrained=True):
        super().__init__()
        from torchvision.models import resnet18, ResNet18_Weights
        net = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        net.fc = nn.Linear(512, n_classes)
        self.net = net

    def forward(self, x):
        n = self.net
        x = n.maxpool(n.relu(n.bn1(n.conv1(x))))
        x = n.layer4(n.layer3(n.layer2(n.layer1(x))))
        f = torch.flatten(n.avgpool(x), 1)
        return n.fc(f), f


def build_model(name, in_ch, n_classes, bn=True, dropout=0.5, pretrained=True):
    import os
    if os.environ.get("SCLERA_NO_PRETRAINED"):  # offline testing only
        pretrained = False
    if name == "svcnn":
        return SVCNN(in_ch, n_classes, bn=bn, dropout=dropout)
    if name == "shallow":
        return ShallowCNN(in_ch, n_classes)
    if name == "resnet18":
        return ResNet18(n_classes, pretrained=pretrained)
    raise ValueError(name)


def count_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
