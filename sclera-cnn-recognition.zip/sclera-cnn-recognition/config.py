"""Configuration for the SV-CNN sclera recognition experiments on UBIRIS.v2.

Set the two data paths before the first run, either here or with the environment variables
SCLERA_DATA_ROOT and SCLERA_ANNOT_ROOT. All other values reproduce the settings described in
the manuscript (Section 2).
"""
import os
from pathlib import Path

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
HERE = Path(__file__).resolve().parent
# Folder with the full UBIRIS.v2 (CLASSES_400_300_Part1 and Part2 inside; searched recursively)
DATA_ROOT = Path(os.environ.get("SCLERA_DATA_ROOT", HERE / "data" / "UBIRIS.v2"))
# Folder with the manually annotated UBIRIS.v2 sclera masks used to train the segmentation network
# (683 masks in the paper). One mask per image, named with the UBIRIS.v2 key, e.g. C100_S1_I14.png;
# binary 0/255 PNG, or RGBA PNG with the mask in the alpha channel. The folder is searched
# recursively; subfolders named image, images, img_mask or image_mask (overlays) are skipped.
SEG_ANNOT_ROOT = Path(os.environ.get("SCLERA_ANNOT_ROOT", HERE / "data" / "sclera_annotations"))

PRED_MASK_DIR = HERE / "pred_masks"   # sclera masks predicted for every UBIRIS.v2 image
CACHE_DIR = HERE / "cache"            # cropped 384 x 768 sclera regions
RESULTS_DIR = HERE / "results"        # one JSON per run, scores, tables, figures

# ----------------------------------------------------------------------------
# UBIRIS.v2 file naming
# ----------------------------------------------------------------------------
# "C12_S2_I7.tiff": eye (class) 12, session 2, image 7. The same key is searched inside
# the file names of the annotation masks. Verify with `python check_dataset.py`.
NAME_REGEX = r"C(?P<cid>\d+)_S(?P<session>\d+)_I(?P<img>\d+)"
IMAGE_EXTS = {".tiff", ".tif", ".jpg", ".jpeg", ".png", ".bmp"}

# ----------------------------------------------------------------------------
# Sclera segmentation (Section 2.2)
# ----------------------------------------------------------------------------
SEG_H, SEG_W = 288, 384          # network input (400 x 300 images are resized)
SEG_EPOCHS = 100
SEG_LR = 3e-4
SEG_BATCH = 8
SEG_TEST_FRACTION = 0.2          # annotated images held out for Table 4 (grouped by eye)
SEG_VAL_FRACTION = 0.1
SEG_STOP_PATIENCE = 20
MIN_SCLERA_PIXELS = 1000         # quality control: images with a smaller predicted sclera are excluded

# ----------------------------------------------------------------------------
# Recognition pre-processing (Sections 2.2-2.3)
# ----------------------------------------------------------------------------
ENH_H, ENH_W = 384, 768          # resolution at which enhancement is computed
NET_H, NET_W = 192, 384          # network input resolution (area downsampling x2)
CLAHE_CLIP = 2.0
CLAHE_TILES = (8, 8)
FRANGI_SIGMAS = (1.0, 2.0, 3.0, 4.0)
FRANGI_BETA = 0.5

# ----------------------------------------------------------------------------
# Protocols (Section 2.7)
# ----------------------------------------------------------------------------
P1_TEST_FRACTION = 0.2           # per eye and session
P1_VAL_FRACTION = 0.1
P2_VAL_FRACTION = 0.15
P2_MIN_TRAIN_IMAGES = 3          # an eye enters P2 if it has >= 3 images in the training session
SPLIT_SEED = 0

# ----------------------------------------------------------------------------
# Training (Section 2.5)
# ----------------------------------------------------------------------------
BATCH_SIZE = 16
LR = 1e-3
LR_RESNET = 1e-4
WEIGHT_DECAY = 1e-4
MAX_EPOCHS = 60
LR_PATIENCE = 5
STOP_PATIENCE = 12
DROPOUT = 0.5
SEEDS = (0, 1, 2)               # Tables 5 and 7; the ablation (Table 6) uses seed 0 only
USE_AMP = True                   # mixed precision (FP16) on the GPU

AUG_ROT_DEG = 10.0
AUG_SCALE = (0.9, 1.1)
AUG_SHIFT = 0.05
AUG_BRIGHT_CONTRAST = 0.15
AUG_BLUR_P = 0.3
AUG_BLUR_SIGMA_MAX = 1.0

NUM_WORKERS = 8
