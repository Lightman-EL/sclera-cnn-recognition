"""Measures the times reported in Section 3.6 (one image at a time):
  (a) sclera segmentation network on the GPU,
  (b) region extraction + CLAHE on the CPU,
  (c) vesselness filter and input tensor on the GPU,
  (d) SV-CNN inference on the GPU.

  python timing.py
"""
import time

import numpy as np
import torch

import config as C
import data
import enhance
import seg
from models import SVCNN


def main(n_cpu=100, n_gpu=300):
    recs = data.load_index()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    amp = C.USE_AMP and dev.type == "cuda"
    sync = (lambda: torch.cuda.synchronize()) if dev.type == "cuda" else (lambda: None)
    rng = np.random.default_rng(0)
    sample = [recs[i] for i in rng.choice(len(recs), size=min(n_cpu, len(recs)), replace=False)]
    img0 = data.read_image(sample[0]["img"])

    # (a) segmentation network (random weights give the same timing as trained ones)
    net = seg.UNetResNet18(pretrained=False).to(dev).eval()
    for _ in range(10):
        seg.predict_prob(net, img0, dev, amp)
    sync(); t0 = time.perf_counter()
    n_seg = min(n_gpu, 100)
    for _ in range(n_seg):
        seg.predict_prob(net, img0, dev, amp)
    sync(); t_seg = 1000 * (time.perf_counter() - t0) / n_seg

    # (b) CPU: read image and mask, crop, resize, CLAHE
    t = []
    for r in sample:
        t0 = time.perf_counter()
        img = data.read_image(r["img"])
        m = data.read_mask(r["mask"], img.shape)
        crop, mc = data.extract_region(img, m)
        E = data.clahe_green(crop)
        t.append(time.perf_counter() - t0)
    t_cpu = 1000 * np.mean(t)

    # (c) vesselness and input tensor on the GPU
    x = torch.from_numpy(E[None, None]).to(dev)
    m_t = torch.from_numpy(mc[None, None]).to(dev)
    for _ in range(20):
        enhance.build_input(x, m_t, "evm")
    sync(); t0 = time.perf_counter()
    for _ in range(n_gpu):
        enhance.build_input(x, m_t, "evm")
    sync(); t_vessel = 1000 * (time.perf_counter() - t0) / n_gpu

    # (d) SV-CNN inference, batch size 1
    model = SVCNN(3, len({r["cid"] for r in recs})).to(dev).eval()
    xin = torch.randn(1, 3, C.NET_H, C.NET_W, device=dev)
    with torch.no_grad(), torch.autocast(device_type=dev.type, dtype=torch.float16, enabled=amp):
        for _ in range(30):
            model(xin)
        sync(); t0 = time.perf_counter()
        for _ in range(n_gpu):
            model(xin)
        sync(); t_cnn = 1000 * (time.perf_counter() - t0) / n_gpu

    gpu = torch.cuda.get_device_name(0) if dev.type == "cuda" else "CPU"
    out = (f"Device: {gpu}\n"
           f"(a) sclera segmentation network (GPU, incl. resize): {t_seg:.2f} ms/image\n"
           f"(b) reading + region extraction + CLAHE (CPU): {t_cpu:.1f} ms/image\n"
           f"(c) vesselness + input tensor (GPU): {t_vessel:.2f} ms/image\n"
           f"(d) SV-CNN inference, batch 1 (GPU): {t_cnn:.2f} ms/image\n")
    print(out)
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (C.RESULTS_DIR / "timing.txt").write_text(out, encoding="utf8")


if __name__ == "__main__":
    main()
