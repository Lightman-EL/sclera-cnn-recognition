"""UBIRIS.v2 indexing, P1/P2 splits, region extraction cache and the PyTorch Dataset."""
import json
import random
import re
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

import config as C

cv2.setNumThreads(0)  # avoid thread oversubscription inside DataLoader workers
KEY = re.compile(C.NAME_REGEX)


# ----------------------------------------------------------------------------
# File access
# ----------------------------------------------------------------------------
def read_image(path, flags=cv2.IMREAD_COLOR):
    data = np.fromfile(str(path), dtype=np.uint8)  # works with non-ASCII Windows paths
    img = cv2.imdecode(data, flags)
    if img is None:
        raise IOError(f"cannot read {path}")
    return img


def read_mask(path, shape=None):
    m = read_image(path, cv2.IMREAD_UNCHANGED)
    if m.ndim == 3 and m.shape[2] == 4 and m[:, :, 3].min() != m[:, :, 3].max():
        m = m[:, :, 3]                    # RGBA mask: the sclera is stored in the alpha channel
    elif m.ndim == 3:
        m = m[:, :, :3].max(axis=2)
    if shape is not None and m.shape[:2] != tuple(shape[:2]):
        m = cv2.resize(m, (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST)
    return (m > 127).astype(np.uint8)


def write_png(path, img):
    cv2.imencode(".png", img)[1].tofile(str(path))


# ----------------------------------------------------------------------------
# Indexing
# ----------------------------------------------------------------------------
def scan_images(root=None):
    """All UBIRIS.v2 images whose file name contains the C<eye>_S<session>_I<image> key."""
    root = Path(root if root is not None else C.DATA_ROOT)
    if not root.exists():
        raise FileNotFoundError(f"DATA_ROOT does not exist: {root}. Edit config.py.")
    files = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in C.IMAGE_EXTS]
    recs, seen = [], set()
    for p in sorted(files):
        m = KEY.search(p.stem)
        if not m or m.group(0) in seen:
            continue
        seen.add(m.group(0))
        recs.append(dict(key=m.group(0), img=str(p), cid=int(m["cid"]), session=int(m["session"]), idx=int(m["img"])))
    return recs, files


def scan_annotations(root=None):
    """Manually annotated sclera masks: key -> mask path."""
    root = Path(root if root is not None else C.SEG_ANNOT_ROOT)
    if not root.exists():
        return {}
    out, rank = {}, {}
    pref = {"segmentationclass": 0, "sclera_mask": 1}
    for p in sorted(root.rglob("*")):
        if not (p.is_file() and p.suffix.lower() in C.IMAGE_EXTS):
            continue
        folder = p.parent.name.lower()
        if folder in {"image", "images", "img_mask", "image_mask"}:   # eye images / overlays, not masks
            continue
        m = KEY.search(p.stem)
        if m:
            r = pref.get(folder, 2)
            if m.group(0) not in out or r < rank[m.group(0)]:
                out[m.group(0)], rank[m.group(0)] = str(p), r
    return out


def load_index(rebuild=False):
    """Records of all usable images (predicted mask present and large enough)."""
    path = C.RESULTS_DIR / "index.json"
    if path.exists() and not rebuild:
        return json.loads(path.read_text(encoding="utf8"))
    imgs, _ = scan_images()
    recs, n_missing, n_small = [], 0, 0
    for r in imgs:
        mp = C.PRED_MASK_DIR / f"{r['key']}.png"
        if not mp.exists():
            n_missing += 1
            continue
        area = int(read_mask(mp).sum())
        if area < C.MIN_SCLERA_PIXELS:
            n_small += 1
            continue
        recs.append(dict(r, mask=str(mp), area=area))
    if not recs:
        raise RuntimeError("No predicted masks found. Run seg.py first.")
    for i, r in enumerate(recs):
        r["id"] = i
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(recs), encoding="utf8")
    (C.RESULTS_DIR / "index_summary.json").write_text(json.dumps(dict(
        images=len(imgs), usable=len(recs), no_mask=n_missing, too_small=n_small)), encoding="utf8")
    return recs


# ----------------------------------------------------------------------------
# Splits (Section 2.7)
# ----------------------------------------------------------------------------
def split_p1(records, seed=C.SPLIT_SEED):
    """Per eye and session: 20 % test, 10 % validation, rest training (at least one training image)."""
    rng = random.Random(seed)
    groups = defaultdict(list)
    for r in records:
        groups[(r["cid"], r["session"])].append(r["id"])
    tr, va, te = [], [], []
    for key in sorted(groups):
        ids = sorted(groups[key])
        rng.shuffle(ids)
        n = len(ids)
        if n == 1:
            tr += ids
            continue
        n_te = max(1, int(round(C.P1_TEST_FRACTION * n)))
        n_va = max(1, int(round(C.P1_VAL_FRACTION * n))) if n >= 3 else 0
        te += ids[:n_te]
        va += ids[n_te:n_te + n_va]
        tr += ids[n_te + n_va:]
    # every test/val eye must also occur in training
    train_eyes = {records[i]["cid"] for i in tr}
    va = [i for i in va if records[i]["cid"] in train_eyes]
    te = [i for i in te if records[i]["cid"] in train_eyes]
    return sorted(tr), sorted(va), sorted(te)


def split_p2(records, fold, seed=C.SPLIT_SEED):
    """Cross-session. fold '12': train session 1 -> test session 2; fold '21': the reverse."""
    s_tr, s_te = (1, 2) if fold == "12" else (2, 1)
    rng = random.Random(seed + 100 + s_tr)
    by_eye = defaultdict(lambda: {1: [], 2: []})
    for r in records:
        if r["session"] in (1, 2):
            by_eye[r["cid"]][r["session"]].append(r["id"])
    tr, va, te = [], [], []
    for cid in sorted(by_eye):
        a, b = sorted(by_eye[cid][s_tr]), sorted(by_eye[cid][s_te])
        if len(a) < C.P2_MIN_TRAIN_IMAGES or not b:
            continue
        rng.shuffle(a)
        n_va = max(1, int(round(C.P2_VAL_FRACTION * len(a))))
        va += a[:n_va]; tr += a[n_va:]; te += b
    return sorted(tr), sorted(va), sorted(te)


def label_map(records, ids):
    eyes = sorted({records[i]["cid"] for i in ids})
    return {c: k for k, c in enumerate(eyes)}


# ----------------------------------------------------------------------------
# Region extraction (Section 2.2): bounding-box crop, aspect-preserving resize, zero padding
# ----------------------------------------------------------------------------
def extract_region(img_bgr, m, out_h=C.ENH_H, out_w=C.ENH_W):
    """m: binary sclera mask {0,1} of the same size as the image."""
    ys, xs = np.nonzero(m)
    if len(ys) == 0:
        raise ValueError("empty sclera mask")
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    crop, mcrop = img_bgr[y0:y1, x0:x1], m[y0:y1, x0:x1]
    h, w = crop.shape[:2]
    s = min(out_h / h, out_w / w)
    nh, nw = max(1, int(round(h * s))), max(1, int(round(w * s)))
    crop = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
    mcrop = cv2.resize(mcrop, (nw, nh), interpolation=cv2.INTER_NEAREST)
    canvas = np.zeros((out_h, out_w, 3), np.uint8)
    mcanvas = np.zeros((out_h, out_w), np.uint8)
    oy, ox = (out_h - nh) // 2, (out_w - nw) // 2
    canvas[oy:oy + nh, ox:ox + nw] = crop
    mcanvas[oy:oy + nh, ox:ox + nw] = mcrop
    return canvas, mcanvas


def _cache_one(r):
    out_img = C.CACHE_DIR / f"{r['key']}_img.png"
    out_msk = C.CACHE_DIR / f"{r['key']}_mask.png"
    if out_img.exists() and out_msk.exists():
        return
    img = read_image(r["img"], cv2.IMREAD_COLOR)
    m = read_mask(r["mask"], img.shape)
    crop, mcrop = extract_region(img, m)
    write_png(out_img, crop)
    write_png(out_msk, mcrop * 255)


def build_cache(records, workers=None):
    workers = C.NUM_WORKERS if workers is None else workers
    C.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    todo = [r for r in records if not (C.CACHE_DIR / f"{r['key']}_mask.png").exists()]
    if not todo:
        return
    print(f"Building region cache for {len(todo)} images (one-time step)...")
    from tqdm import tqdm
    if workers > 1:
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(max_workers=workers) as ex:
            list(tqdm(ex.map(_cache_one, todo, chunksize=16), total=len(todo)))
    else:
        for r in tqdm(todo):
            _cache_one(r)


def load_cached(key):
    img = read_image(C.CACHE_DIR / f"{key}_img.png", cv2.IMREAD_COLOR)
    msk = read_image(C.CACHE_DIR / f"{key}_mask.png", cv2.IMREAD_GRAYSCALE)
    return img, (msk > 127).astype(np.uint8)


# ----------------------------------------------------------------------------
# Augmentation and CLAHE (Sections 2.3, 2.5)
# ----------------------------------------------------------------------------
_CLAHE = None


def clahe_green(img_bgr):
    global _CLAHE
    if _CLAHE is None:
        _CLAHE = cv2.createCLAHE(clipLimit=C.CLAHE_CLIP, tileGridSize=C.CLAHE_TILES)
    return _CLAHE.apply(np.ascontiguousarray(img_bgr[:, :, 1]))


def augment(img, msk, rng):
    h, w = msk.shape
    ang = rng.uniform(-C.AUG_ROT_DEG, C.AUG_ROT_DEG)
    sc = rng.uniform(*C.AUG_SCALE)
    M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, sc)
    M[0, 2] += rng.uniform(-C.AUG_SHIFT, C.AUG_SHIFT) * w
    M[1, 2] += rng.uniform(-C.AUG_SHIFT, C.AUG_SHIFT) * h
    img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
    msk = cv2.warpAffine(msk, M, (w, h), flags=cv2.INTER_NEAREST, borderValue=0)
    f = img.astype(np.float32)
    a = rng.uniform(1 - C.AUG_BRIGHT_CONTRAST, 1 + C.AUG_BRIGHT_CONTRAST)
    b = rng.uniform(1 - C.AUG_BRIGHT_CONTRAST, 1 + C.AUG_BRIGHT_CONTRAST)
    mean = f[msk > 0].mean() if msk.any() else f.mean()
    img = np.clip(((f - mean) * a + mean) * b, 0, 255).astype(np.uint8)
    if rng.random() < C.AUG_BLUR_P:
        img = cv2.GaussianBlur(img, (0, 0), rng.uniform(0.1, C.AUG_BLUR_SIGMA_MAX))
    return img, msk


class ScleraDataset(Dataset):
    """Returns (x_uint8, mask_uint8, label). mode 'rgb' -> 3 x H x W RGB; 'e'/'ev'/'evm' -> 1 x H x W (E)."""

    def __init__(self, records, ids, mode, labels, train=False, seed=0):
        self.recs = {r["id"]: r for r in records}
        self.ids = list(ids)
        self.mode = mode
        self.labels = labels
        self.train = train
        self.seed = seed
        self._rng = None  # created lazily inside each worker; persists across epochs

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        r = self.recs[self.ids[i]]
        img, msk = load_cached(r["key"])
        if self.train:
            if self._rng is None:
                info = torch.utils.data.get_worker_info()
                self._rng = random.Random(self.seed * 1000 + (info.id if info else 0))
            img, msk = augment(img, msk, self._rng)
        if self.mode == "rgb":
            x = np.ascontiguousarray(img[:, :, ::-1].transpose(2, 0, 1))
        else:
            x = clahe_green(img)[None]
        return torch.from_numpy(x), torch.from_numpy(msk[None]), self.labels[r["cid"]]
