"""Identification (15)-(16) and verification (17) metrics."""
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_curve, auc


def identification(y_true, y_pred):
    p, r, f, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    return dict(acc=100 * accuracy_score(y_true, y_pred), precision=float(p), recall=float(r), f1=float(f))


def all_pairs(sim, labels):
    """Upper-triangle scores of an N x N similarity matrix and genuine (1) / impostor (0) labels."""
    labels = np.asarray(labels)
    iu = np.triu_indices(len(labels), k=1)
    return sim[iu], (labels[iu[0]] == labels[iu[1]]).astype(np.int8)


def verification(scores, genuine):
    fpr, tpr, _ = roc_curve(genuine, scores)
    fnr = 1 - tpr
    d = fnr - fpr                      # decreasing from +1 to -1
    k = int(np.argmax(d <= 0))         # first point where FRR <= FAR
    if k == 0:
        eer = (fpr[0] + fnr[0]) / 2
    else:
        t = d[k - 1] / (d[k - 1] - d[k])
        eer = fpr[k - 1] + t * (fpr[k] - fpr[k - 1])
    gar = float(np.interp(1e-3, fpr, tpr))
    gar1 = float(np.interp(1e-2, fpr, tpr))
    return dict(eer=100 * float(eer), gar_far01=100 * gar, gar_far1=100 * gar1, auc=float(auc(fpr, tpr)),
                n_gen=int(genuine.sum()), n_imp=int((1 - genuine).sum()))


def cosine_matrix(emb):
    emb = emb / (np.linalg.norm(emb, axis=1, keepdims=True) + 1e-12)
    return emb @ emb.T
