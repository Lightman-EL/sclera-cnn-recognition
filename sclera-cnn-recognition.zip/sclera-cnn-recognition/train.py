"""One training/evaluation run.

Examples:
  python train.py --model svcnn --input evm --protocol P1 --seed 0
  python train.py --model resnet18 --input rgb --protocol P1 --seed 3
  python train.py --model svcnn --input evm --protocol P2 --fold 12 --seed 0
  python train.py --model svcnn --input evm --protocol P1 --seed 0 --no-aug
  python train.py --model resnet18 --input evm --protocol P1 --seed 0
  python train.py --model svcnn --input rgb --protocol P1 --seed 0 --no-dropout --epochs 150
"""
import argparse
import copy
import json
import random
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

import config as C
import data
import enhance
import metrics
from models import build_model, count_params


def run_name(a):
    parts = [a.protocol] + ([a.fold] if a.protocol == "P2" else []) + [f"{a.model}_{a.input}"]
    if a.no_bn:
        parts[-1] += "_nobn"
    if a.no_dropout:
        parts[-1] += "_nodrop"
    if a.no_aug:
        parts[-1] += "_noaug"
    epochs = getattr(a, "epochs", None)
    if epochs is not None and int(epochs) != C.MAX_EPOCHS:
        parts[-1] += f"_ep{int(epochs)}"   # longer (or shorter) training budget than in the main runs
    return "__".join(parts) + f"__seed{a.seed}"


def set_seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


def make_loader(recs, ids, mode, labels, train, seed, workers, shuffle, persistent=True):
    ds = data.ScleraDataset(recs, ids, mode, labels, train=train, seed=seed)
    g = torch.Generator(); g.manual_seed(seed)
    # drop_last for training: a final batch of one image would break batch normalisation
    return DataLoader(ds, batch_size=C.BATCH_SIZE, shuffle=shuffle, num_workers=workers, pin_memory=True,
                      persistent_workers=persistent and workers > 0, drop_last=train and shuffle, generator=g)


@torch.no_grad()
def evaluate(model, loader, mode, std, device, amp=False, want_emb=True):
    model.eval()
    logits, embs, ys, loss_sum = [], [], [], 0.0
    ce = nn.CrossEntropyLoss(reduction="sum")
    for x, m, y in loader:
        xin = std(enhance.build_input(x.to(device, non_blocking=True), m.to(device, non_blocking=True), mode))
        xin = xin.contiguous(memory_format=torch.channels_last)
        y = y.to(device)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
            out, e = model(xin)
        out = out.float()
        loss_sum += ce(out, y).item()
        logits.append(out.cpu()); ys.append(y.cpu())
        if want_emb:
            embs.append(e.float().cpu())
    logits, ys = torch.cat(logits), torch.cat(ys)
    embs = torch.cat(embs) if want_emb else None
    return loss_sum / len(ys), logits.numpy(), embs, ys.numpy()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["svcnn", "shallow", "resnet18"], default="svcnn")
    ap.add_argument("--input", choices=["rgb", "e", "ev", "evm"], default="evm")
    ap.add_argument("--protocol", choices=["P1", "P2"], default="P1")
    ap.add_argument("--fold", choices=["12", "21"], default=None,
                    help="P2: '12' = train session 1, test session 2; '21' = the reverse")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-bn", action="store_true")
    ap.add_argument("--no-dropout", action="store_true")
    ap.add_argument("--no-aug", action="store_true")
    ap.add_argument("--epochs", type=int, default=C.MAX_EPOCHS)
    ap.add_argument("--workers", type=int, default=C.NUM_WORKERS)
    ap.add_argument("--force", action="store_true", help="re-run even if the result file exists")
    a = ap.parse_args(argv)
    if a.protocol == "P2" and a.fold is None:
        ap.error("--fold is required for P2")
    if a.model == "shallow" and a.input != "rgb":
        ap.error("the shallow CNN uses --input rgb")
    if a.model == "resnet18" and a.input not in ("rgb", "evm"):
        ap.error("ResNet-18 needs a three-channel input: --input rgb or --input evm")

    name = run_name(a)
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out_json = C.RESULTS_DIR / f"{name}.json"
    if out_json.exists() and not a.force:
        print(f"[skip] {name} already done"); return
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
    amp = C.USE_AMP and device.type == "cuda"
    print(f"=== {name} on {torch.cuda.get_device_name(0) if device.type == 'cuda' else 'CPU'} ===")

    recs = data.load_index()
    data.build_cache(recs, workers=a.workers)
    tr, va, te = data.split_p1(recs) if a.protocol == "P1" else data.split_p2(recs, a.fold)
    labels = data.label_map(recs, tr)
    va = [i for i in va if recs[i]["cid"] in labels]
    te = [i for i in te if recs[i]["cid"] in labels]
    n_classes = len(labels)
    set_seed(a.seed)

    w_eval = max(1, a.workers // 4) if a.workers > 0 else 0
    train_loader = make_loader(recs, tr, a.input, labels, not a.no_aug, a.seed, a.workers, True)
    val_loader = make_loader(recs, va, a.input, labels, False, a.seed, w_eval, False)
    stat_loader = make_loader(recs, tr, a.input, labels, False, a.seed, w_eval, False, persistent=False)
    test_loader = make_loader(recs, te, a.input, labels, False, a.seed, w_eval, False, persistent=False)

    # ImageNet statistics for the pre-trained network on RGB; training-set statistics otherwise
    # (the E, V, M channels are not natural colour channels)
    std = enhance.Standardizer.imagenet(device) if (a.model == "resnet18" and a.input == "rgb") else \
        enhance.Standardizer.from_loader(stat_loader, a.input, device)
    model = build_model(a.model, enhance.in_channels(a.input), n_classes, bn=not a.no_bn,
                        dropout=0.0 if a.no_dropout else C.DROPOUT).to(device)
    model = model.to(memory_format=torch.channels_last)
    lr = C.LR_RESNET if a.model == "resnet18" else C.LR
    opt = torch.optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), weight_decay=C.WEIGHT_DECAY)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=C.LR_PATIENCE)
    ce = nn.CrossEntropyLoss()
    scaler = torch.amp.GradScaler(device.type, enabled=amp)

    best, best_state, best_ep, bad, t0, history = float("inf"), None, 0, 0, time.time(), []
    early = False
    for ep in range(1, a.epochs + 1):
        model.train(); run_loss = n = 0
        for x, m, y in train_loader:
            xin = std(enhance.build_input(x.to(device, non_blocking=True), m.to(device, non_blocking=True), a.input))
            xin = xin.contiguous(memory_format=torch.channels_last)
            y = y.to(device, non_blocking=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
                out, _ = model(xin)
            loss = ce(out.float(), y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
            run_loss += loss.item() * len(y); n += len(y)
        vloss, vlog, _, vy = evaluate(model, val_loader, a.input, std, device, amp, want_emb=False)
        vacc = 100 * (vlog.argmax(1) == vy).mean()
        sched.step(vloss)
        history.append(dict(epoch=ep, train_loss=run_loss / n, val_loss=vloss, val_acc=float(vacc),
                            lr=opt.param_groups[0]["lr"]))
        print(f"ep {ep:3d}  train {run_loss / n:.4f}  val {vloss:.4f}  val_acc {vacc:6.2f}%  "
              f"lr {opt.param_groups[0]['lr']:.1e}  {time.time() - t0:6.0f}s", flush=True)
        if vloss < best - 1e-6:
            best, best_state, best_ep, bad = vloss, copy.deepcopy(model.state_dict()), ep, 0
        else:
            bad += 1
            if bad >= C.STOP_PATIENCE:
                print("early stopping"); early = True; break
    train_time = time.time() - t0
    model.load_state_dict(best_state)

    _, logits, emb, y = evaluate(model, test_loader, a.input, std, device, amp)
    res = metrics.identification(y, logits.argmax(1))
    with torch.no_grad():  # cosine similarity of all test pairs, computed on the GPU
        e = torch.nn.functional.normalize(emb.to(device), dim=1)
        sim = (e @ e.T).float().cpu().numpy()
    del e
    scores, gen = metrics.all_pairs(sim, y)
    res.update(metrics.verification(scores, gen))
    res.update(name=name, model=a.model, input=a.input, protocol=a.protocol, fold=a.fold, seed=a.seed,
               no_bn=a.no_bn, no_dropout=a.no_dropout, no_aug=a.no_aug, params=count_params(model), n_classes=n_classes, amp=amp,
               epochs=len(history), max_epochs=a.epochs, best_epoch=best_ep, early_stopped=early,
               best_val_loss=best, train_time_s=train_time,
               n_train=len(tr), n_val=len(va), n_test=len(te),
               device=torch.cuda.get_device_name(0) if device.type == "cuda" else "cpu", history=history)
    np.savez_compressed(C.RESULTS_DIR / f"{name}_scores.npz", scores=scores.astype(np.float32), genuine=gen)
    if a.seed == 0 and a.protocol == "P1":
        torch.save(dict(state=model.state_dict(), mean=std.mean.cpu(), std=std.std.cpu()),
                   C.RESULTS_DIR / f"{name}_model.pt")
    out_json.write_text(json.dumps(res, indent=1))
    print(f"TEST  acc {res['acc']:.2f}%  F1 {res['f1']:.4f}  EER {res['eer']:.2f}%  "
          f"GAR@FAR=0.1% {res['gar_far01']:.2f}%  ({train_time / 60:.1f} min)")


if __name__ == "__main__":
    main()
