"""Runs every experiment of the manuscript in order of importance. Re-start at any time:
finished runs are skipped.

  python run_all.py            # segmentation (if needed) + Tables 5-7, five seeds
  python run_all.py --smoke    # 2 epochs per run, seed 0 only: checks that everything works
  python run_all.py --only P1  # only Tables 5-6
"""
import argparse
import json
import shutil
import time

import numpy as np

import config as C
import data
import lbp_svm
import seg
import train


def jobs(seeds):
    """Order: everything with seed 0 first (a complete single-run set of Tables 5-7),
    then the remaining seeds for Tables 5 and 7. The ablation (Table 6) uses seed 0 only."""
    def t5(s):
        return [["--protocol", "P1", "--model", m, "--input", i, "--seed", str(s)]
                for m, i in [("svcnn", "evm"), ("svcnn", "rgb"), ("resnet18", "rgb"), ("shallow", "rgb")]]

    def t6():
        return [["--protocol", "P1", "--model", "svcnn", "--seed", "0"] + v
                for v in [["--input", "e"], ["--input", "ev"], ["--input", "evm", "--no-bn"],
                          ["--input", "evm", "--no-dropout"], ["--input", "evm", "--no-aug"]]]

    def t7(s):
        return [["--protocol", "P2", "--fold", f, "--model", "svcnn", "--input", i, "--seed", str(s)]
                for f in ["12", "21"] for i in ["rgb", "evm"]]

    seeds = list(seeds)
    J = t5(seeds[0]) + t6() + t7(seeds[0])
    for s in seeds[1:]:
        J += t5(s) + t7(s)
    return J


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--only", choices=["P1", "P2"], default=None)
    ap.add_argument("--workers", type=int, default=C.NUM_WORKERS)
    a = ap.parse_args(argv)
    saved = (C.RESULTS_DIR, C.PRED_MASK_DIR, C.CACHE_DIR)
    try:
        _run(a)
    finally:  # restore the folders (important when called repeatedly from a notebook)
        C.RESULTS_DIR, C.PRED_MASK_DIR, C.CACHE_DIR = saved


def _run(a):
    if a.smoke:
        real = C.RESULTS_DIR
        C.RESULTS_DIR = C.HERE / "results_smoke"
        C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        if (real / "seg_results.json").exists() and C.PRED_MASK_DIR.exists():
            # reuse the real segmentation masks and region cache (they are needed by the full run anyway)
            shutil.copy(real / "seg_results.json", C.RESULTS_DIR / "seg_results.json")
        else:
            C.PRED_MASK_DIR = C.HERE / "pred_masks_smoke"
            C.CACHE_DIR = C.HERE / "cache_smoke"

    if not (C.RESULTS_DIR / "seg_results.json").exists():
        print("=== sclera segmentation (Table 4) ===")
        seg.main((["--epochs", "10"] if a.smoke else []) + ["--workers", str(a.workers)])
    recs = data.load_index(rebuild=a.smoke)  # the smoke index is always rebuilt from the current masks
    data.build_cache(recs, workers=a.workers)

    if a.only != "P2" and not (C.RESULTS_DIR / "P1__lbp_svm__seed0.json").exists():
        print("=== P1__lbp_svm ===")
        tr, va, te = data.split_p1(recs)
        res, scores, gen = lbp_svm.run(recs, tr, va, te)
        (C.RESULTS_DIR / "P1__lbp_svm__seed0.json").write_text(json.dumps(res, indent=1))
        np.savez_compressed(C.RESULTS_DIR / "P1__lbp_svm__seed0_scores.npz", scores=scores, genuine=gen)
        print(f"TEST  acc {res['acc']:.2f}%  EER {res['eer']:.2f}%")

    seeds = [0] if a.smoke else list(C.SEEDS)
    todo = [j for j in jobs(seeds) if a.only is None or j[1] == a.only]
    t0 = time.time()
    for k, j in enumerate(todo, 1):
        extra = ["--epochs", "2"] if a.smoke else []
        print(f"\n##### job {k}/{len(todo)}  (elapsed {(time.time() - t0) / 3600:.2f} h)")
        train.main(j + extra + ["--workers", str(a.workers)])
    print(f"\nAll done in {(time.time() - t0) / 3600:.2f} h. Now run: python make_tables.py"
          + (" --smoke" if a.smoke else ""))


if __name__ == "__main__":
    main()
